(() => {
  if (window.top !== window || document.getElementById("hack-hotdog-extension")) return;

  const host = document.createElement("div");
  host.id = "hack-hotdog-extension";
  host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none";
  (document.documentElement || document.body).appendChild(host);
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `
    <style>
      *{box-sizing:border-box;font-family:Arial,sans-serif}
      .dog-button,.pizza-button,.menu-button{position:fixed;bottom:22px;pointer-events:auto;border:2px solid #fff;border-radius:999px;padding:12px 17px;color:#fff;font-size:15px;font-weight:800;box-shadow:0 5px 20px #0008;cursor:pointer;transition:transform .15s,filter .15s}
      .dog-button{right:22px;background:#e64228;box-shadow:0 5px 20px #0008,0 0 0 2px #e64228}
      .pizza-button{right:157px;background:#d78820;box-shadow:0 5px 20px #0008,0 0 0 2px #d78820}
      .menu-button{right:288px;background:#6846c7}
      .dog-button:hover,.pizza-button:hover,.menu-button:hover{transform:scale(1.08);filter:brightness(1.1)}.dog-button:active,.pizza-button:active,.menu-button:active{transform:scale(.94)}
      .menu{position:fixed;right:22px;bottom:76px;width:min(410px,calc(100vw - 28px));max-height:min(76vh,680px);padding:14px;display:flex;flex-direction:column;gap:11px;border:1px solid #ffffff55;border-radius:19px;background:#171525f5;color:white;box-shadow:0 12px 38px #000a;pointer-events:auto;backdrop-filter:blur(14px)}
      .menu[hidden]{display:none}.gadget-heading{display:flex;align-items:center;justify-content:space-between}.gadget-heading strong{font-size:20px}.gadget-heading small{color:#bdb8d4}.gadget-search{width:100%;padding:12px 14px;border:1px solid #ffffff30;border-radius:12px;background:#0e0d18;color:white;font-size:15px;outline:none}.gadget-search:focus{border-color:#a78bfa;box-shadow:0 0 0 3px #a78bfa33}.gadget-categories{display:flex;gap:7px;overflow-x:auto;padding-bottom:2px}.gadget-categories button,.menu .gadget-grid button{flex:none;border:1px solid #ffffff20;border-radius:11px;padding:9px 11px;background:#29263c;color:white;font-weight:700;cursor:pointer;white-space:nowrap}.gadget-categories button.active{background:#6846c7;border-color:#a78bfa}.gadget-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;overflow-y:auto;padding-right:2px}.menu .gadget-grid button{text-align:left;white-space:normal;min-height:43px;transition:background .15s,transform .15s}.menu .gadget-grid button:hover{background:#51466e;transform:translateY(-1px)}.gadget-empty{padding:18px;text-align:center;color:#c9c5d8}
      .clear-button,.stop-button{position:fixed;top:18px;pointer-events:auto;border:0;border-radius:12px;padding:14px 22px;font-size:clamp(17px,2vw,24px);font-weight:900;box-shadow:0 5px 24px #0008;cursor:pointer;animation:buttonIn .22s ease-out both}
      .clear-button{left:50%;transform:translateX(-50%);background:#ffcf33;color:#251300}.clear-button:hover{filter:brightness(1.08);transform:translateX(-50%) scale(1.04)}
      .stop-button{right:18px;background:#df3150;color:#fff}.stop-button[hidden]{display:none}
      .sticker{position:fixed;z-index:2;display:grid;place-items:center;width:94px;height:94px;border:5px solid white;border-radius:50%;background:#fff;box-shadow:0 5px 22px #0006,0 0 0 2px #e63b24;pointer-events:none;font-size:59px;line-height:1;animation:popIn .42s cubic-bezier(.17,.89,.32,1.35) both;user-select:none}
      .sticker.out{animation:popOut .18s ease-in forwards}
      .fun-layer{position:fixed;inset:0;pointer-events:none;overflow:hidden}
      .confetti{position:absolute;top:-40px;font-size:28px;animation:confettiFall var(--fall) linear forwards;filter:drop-shadow(0 2px 2px #0006)}
      .duck{position:absolute;left:-80px;top:var(--y);font-size:54px;animation:duckRun 6s linear forwards;filter:drop-shadow(0 4px 5px #0007)}
      .random-image{position:absolute;width:145px;min-height:150px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;border:5px solid #fff;border-radius:18px;background:var(--card,#ffe98b);color:#242018;box-shadow:0 7px 24px #0007;font-size:72px;line-height:1;animation:popIn .42s cubic-bezier(.17,.89,.32,1.35) both;transform:rotate(var(--tilt));}
      .random-image small{font-size:12px;font-weight:900;text-transform:uppercase;letter-spacing:.07em}
      .toast{position:absolute;top:18%;left:50%;transform:translateX(-50%);padding:13px 20px;border:2px solid #fff;border-radius:18px;background:#27334bf2;color:white;font-weight:800;font-size:18px;box-shadow:0 8px 25px #0008;animation:toastIn .3s ease-out both}
      .movie-modal{position:fixed;inset:0;display:grid;place-items:center;padding:18px;background:#050711b9;pointer-events:auto}
      .movie-modal[hidden]{display:none}.movie-card{width:min(440px,100%);padding:24px;border:1px solid #ffffff55;border-radius:20px;background:#171525;color:#fff;box-shadow:0 15px 50px #000b}
      .movie-card h2{margin:0 0 8px;font-size:24px}.movie-card p{margin:0 0 18px;color:#c8c6d9}.movie-card input{width:100%;padding:13px;border:1px solid #ffffff55;border-radius:10px;background:#090912;color:#fff;font-size:17px;outline-color:#a78bfa}.movie-actions{display:flex;justify-content:flex-end;gap:9px;margin-top:15px}.movie-actions button{border:0;border-radius:10px;padding:11px 14px;font-weight:800;cursor:pointer}.movie-cancel{background:#343247;color:#fff}.movie-submit{background:#ee394f;color:#fff}
      .disco{position:fixed;inset:0;opacity:.28;background:linear-gradient(120deg,#ff004c,#ffed00,#00e5ff,#aa00ff,#ff004c);background-size:400% 400%;animation:disco 1.8s linear infinite}.spotlight{position:fixed;inset:0;pointer-events:none;background:radial-gradient(circle 155px at var(--x,50%) var(--y,50%),transparent 0 78px,#080711df 168px);z-index:2147483001;transition:background-position .04s}
      .pizza-workshop{position:fixed;inset:0;display:grid;place-items:center;padding:16px;background:#090915d9;pointer-events:auto}.pizza-workshop[hidden]{display:none}.pizza-maker{width:min(760px,100%);max-height:94vh;overflow:auto;padding:20px;border:1px solid #ffffff45;border-radius:20px;background:#201b32;color:#fff;box-shadow:0 14px 50px #000b}.pizza-head{display:flex;justify-content:space-between;align-items:center;gap:10px}.pizza-head h2{margin:0;font-size:23px}.pizza-head button,.pizza-actions button{border:0;border-radius:10px;padding:10px 14px;background:#51466e;color:white;font-weight:800;cursor:pointer}.pizza-layout{display:grid;grid-template-columns:minmax(180px,1fr) minmax(220px,1.2fr);gap:18px;align-items:center;margin-top:16px}.ingredient-bins{display:grid;grid-template-columns:1fr 1fr;gap:9px}.ingredient-bin{display:grid;place-items:center;gap:4px;min-height:70px;border:2px dashed #ffffff3a;border-radius:12px;background:#ffffff0a;color:white;font-size:25px;cursor:grab}.ingredient-bin small{font-size:12px}.pizza-dough{position:relative;width:min(100%,330px);aspect-ratio:1;border:11px solid #b66c31;border-radius:50%;background:radial-gradient(circle at 50% 50%,#f8d995 0 73%,#eebd69 74% 100%);box-shadow:inset 0 0 0 4px #f4cc82,0 7px 18px #0007;margin:auto;overflow:hidden}.pizza-dough.drag-over{outline:5px solid #a78bfa;outline-offset:3px}.dough-hint{position:absolute;inset:0;display:grid;place-items:center;color:#79512b;font-weight:800;pointer-events:none;text-align:center;padding:28px}.topping{position:absolute;transform:translate(-50%,-50%);font-size:27px;filter:drop-shadow(0 2px 1px #875b26);user-select:none}.pizza-actions{display:flex;justify-content:flex-end;gap:9px;margin-top:14px}.pizza-actions .bake{background:#d78820}.pizza-status{min-height:20px;color:#ddd;font-size:13px;margin-top:9px}
      .music-workshop{position:fixed;inset:0;display:grid;place-items:center;padding:clamp(8px,2vw,24px);background:#090915eF;pointer-events:auto;z-index:2147483646}.music-workshop[hidden]{display:none}.music-maker{width:min(1500px,100%);max-height:96vh;overflow:auto;padding:clamp(16px,2.5vw,30px);border:1px solid #ffffff45;border-radius:22px;background:linear-gradient(145deg,#1b1730,#292044);color:white;box-shadow:0 14px 50px #000c}.music-top{display:flex;justify-content:space-between;align-items:center;gap:12px}.music-top h2{margin:0;font-size:clamp(22px,3vw,32px)}.music-top button,.music-actions button,.music-ai button,.music-library button{border:0;border-radius:10px;padding:10px 14px;background:#51466e;color:white;font-weight:800;cursor:pointer}.music-controls{display:flex;align-items:center;flex-wrap:wrap;gap:16px;margin:16px 0}.music-controls label{display:flex;align-items:center;gap:8px;color:#eee}.music-controls input{accent-color:#bb86fc}.music-controls select{padding:8px 10px;border:1px solid #ffffff25;border-radius:8px;background:#201b32;color:white}.music-metronome-label input{width:17px;height:17px}.music-library{display:grid;grid-template-columns:minmax(180px,1fr) minmax(180px,1fr) auto auto auto;align-items:end;gap:9px;margin:14px 0;padding:14px;border:1px solid #ffffff20;border-radius:13px;background:#ffffff08}.music-library label{display:grid;gap:6px;color:#ddd;font-size:13px;font-weight:700}.music-library input,.music-library select{min-width:0;width:100%;padding:11px;border:1px solid #ffffff25;border-radius:9px;background:#201b32;color:white;font:inherit}.music-library .music-delete{background:#71364b}.music-library button:disabled{opacity:.45;cursor:not-allowed}.music-library-status{grid-column:1/-1;margin:0;color:#d7c9ff;font-size:13px}.music-grid-wrap{overflow-x:auto;padding:3px 1px 10px}.music-grid{min-width:1320px;display:grid;grid-template-columns:130px repeat(32,minmax(30px,1fr));gap:7px;align-items:center}.music-grid .instrument{font-size:13px;color:#ddd}.music-grid .step{height:42px;border:1px solid #ffffff20;border-radius:8px;background:#302945;cursor:pointer}.music-grid .step:nth-child(4n + 2){margin-left:3px}.music-grid .step.on{background:#a36af5;box-shadow:0 0 12px #a36af866}.music-grid .step.playing{outline:2px solid white}.music-actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:16px}.music-actions .play,.music-ai .generate{background:#7c4dce}.music-status{margin-top:10px;color:#d7c9ff;font-size:14px;min-height:20px}.music-ai{display:grid;grid-template-columns:minmax(220px,1fr) minmax(140px,220px) auto;align-items:center;gap:10px;margin:16px 0;padding:16px;border:1px solid #ffffff20;border-radius:14px;background:#ffffff08}.music-ai strong{grid-column:1/-1;font-size:16px}.music-ai small{grid-column:1/-1;color:#c2bdd4;line-height:1.5}.music-ai input,.music-ai select{min-width:0;width:100%;border:1px solid #ffffff25;border-radius:9px;padding:12px;background:#201b32;color:white;font:inherit}.music-ai .generate{min-height:44px;white-space:nowrap}.music-hint{color:#b9b3cc;font-size:13px;margin:4px 0 8px}.voice-open{background:#342b51!important}.voice-panel{margin-top:14px;padding:18px;border:1px solid #ffffff24;border-radius:16px;background:#100d1ca8}.voice-panel[hidden],.voice-mode[hidden]{display:none}.voice-choices{display:grid;grid-template-columns:1fr 1fr;gap:12px}.voice-choice,.voice-button{padding:14px;border:1px solid #ffffff30;border-radius:12px;background:#302945;color:#fff;font:inherit;font-weight:800;cursor:pointer}.voice-choice span{display:block;margin-top:7px;color:#c3bdd4;font-size:13px;font-weight:400;line-height:1.5}.voice-note{padding:12px;border-radius:10px;background:#ffffff0b;color:#d0cadd;font-size:13px;line-height:1.55}.voice-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:14px 0}.voice-form label{display:grid;gap:6px;color:#e5e0ef;font-size:13px}.voice-form select,.voice-form input,.voice-lyrics{width:100%;padding:11px;border:1px solid #ffffff30;border-radius:9px;background:#211b32;color:white;font:inherit}.voice-lyrics{min-height:90px;resize:vertical}.voice-actions{display:flex;flex-wrap:wrap;gap:9px;margin:12px 0}.voice-button.primary{background:#7750c2}.voice-button:disabled{opacity:.5;cursor:not-allowed}.voice-phrase{padding:13px;border:1px solid #ffffff20;border-radius:11px;background:#ffffff08;color:#fff;font-size:17px;line-height:1.6}.voice-status{min-height:22px;color:#d7c9ff;font-size:13px;line-height:1.5}.voice-meter{height:8px;margin:10px 0;border-radius:99px;background:#ffffff20;overflow:hidden}.voice-meter span{display:block;width:0;height:100%;border-radius:inherit;background:linear-gradient(90deg,#9273ff,#eb91d3);transition:width .1s}@media(max-width:850px){.music-library{grid-template-columns:1fr 1fr}.music-library button{min-height:42px}}@media(max-width:700px){.music-ai{grid-template-columns:1fr}.music-ai strong,.music-ai small{grid-column:auto}.music-grid{min-width:1320px}.music-actions button{flex:1 1 42%}.voice-choices,.voice-form{grid-template-columns:1fr}}
      .tool-card{position:fixed;right:18px;bottom:76px;width:min(350px,calc(100vw - 30px));max-height:min(72vh,560px);overflow:auto;padding:18px;border:1px solid #ffffff55;border-radius:18px;background:#171525f5;color:#fff;box-shadow:0 10px 35px #000a;pointer-events:auto}
      .tool-card[hidden]{display:none}.tool-card h2{margin:0 0 8px;font-size:20px}.tool-card p{margin:6px 0;color:#ddd}.tool-card button,.tool-card input{border:1px solid #ffffff35;border-radius:9px;padding:9px;background:#29263c;color:white}.tool-card button{cursor:pointer;font-weight:700}.tool-card .tool-close{float:right}.map{position:relative;height:150px;margin:12px 0;border:1px solid #ffffff55;border-radius:12px;background:linear-gradient(180deg,#63c5eb 0 35%,#a8dcf0 35% 65%,#63c5eb 65%);overflow:hidden}.map:before{content:"";position:absolute;inset:13px 28px;background:#78bd81;clip-path:polygon(3% 25%,17% 8%,30% 18%,33% 35%,43% 40%,38% 55%,28% 58%,27% 79%,19% 94%,13% 75%,8% 57%,0 47%,53% 15%,67% 10%,73% 21%,84% 18%,91% 33%,82% 44%,72% 40%,67% 54%,57% 48%,53% 31%,74% 62%,86% 70%,80% 89%,72% 84%,67% 70%,60% 65%)}.map-pin{position:absolute;left:var(--x);top:var(--y);font-size:24px;filter:drop-shadow(0 1px 2px #000);animation:pinPulse 1.2s infinite alternate}.tool-row{display:flex;flex-wrap:wrap;gap:7px;margin-top:10px}.tool-row input{flex:1;min-width:130px}.tool-close{background:#51466e!important}
      @keyframes popIn{0%{opacity:0;transform:scale(.05) rotate(-35deg)}75%{opacity:1;transform:scale(1.2) rotate(8deg)}100%{transform:scale(1) rotate(var(--tilt))}}
      @keyframes popOut{to{opacity:0;transform:scale(.05) rotate(45deg)}}
      @keyframes buttonIn{from{opacity:0;top:-40px}to{opacity:1;top:18px}}
      @keyframes confettiFall{to{transform:translateY(115vh) rotate(820deg);opacity:.15}}
      @keyframes duckRun{0%{transform:translateX(0) rotate(-4deg)}50%{transform:translateX(55vw) translateY(-18px) rotate(5deg)}100%{transform:translateX(115vw) rotate(-3deg)}}
      @keyframes toastIn{from{opacity:0;top:10%;scale:.8}to{opacity:1;top:18%;scale:1}}
      @keyframes disco{to{background-position:100% 100%}}
      @keyframes pinPulse{to{transform:scale(1.3)}}
      @media(max-width:600px){.dog-button,.pizza-button,.menu-button{bottom:12px;padding:10px 13px;font-size:13px}.dog-button{right:12px}.pizza-button{right:117px}.menu-button{right:222px}.sticker{width:76px;height:76px;font-size:48px}.stop-button{top:68px;right:12px}}
    </style>
    <div class="fun-layer"></div>
    <button class="menu-button" type="button" aria-expanded="false">🎪 Gadgets</button>
    <div class="menu" hidden>
      <div class="gadget-heading"><strong>🎪 Mes gadgets</strong><small>Choisis ton outil</small></div>
      <input class="gadget-search" type="search" placeholder="🔎 Chercher un gadget…" aria-label="Chercher un gadget">
      <nav class="gadget-categories" aria-label="Catégories">
        <button type="button" class="active" data-category="all">Tout</button><button type="button" data-category="fun">🎉 Fun</button><button type="button" data-category="page">🧰 Page</button><button type="button" data-category="search">🔎 Recherche</button>
      </nav>
      <div class="gadget-grid">
      <button data-mode="confetti">🎉 Confettis</button><button data-mode="image">🖼️ Image au pif</button>
      <button data-mode="movie">🎬 Bande-annonce</button>
      <button data-mode="ducks">🦆 Parade de canards</button>
      <button data-mode="disco">🪩 Mode disco</button><button data-mode="shake">🫨 Site qui tremble</button>
      <button data-mode="toast">✨ Messages inutiles</button><button data-mode="coin">🪙 Pluie de pièces</button>
      <button data-mode="spotlight">🔦 Projecteur de souris</button><button data-mode="pomodoro">⏱️ Minuteur Pomodoro</button>
      <button data-mode="palette">🎨 Palette de couleurs</button><button data-mode="wordcount">🔢 Compteur de mots</button>
      <button data-mode="soundboard">🎛️ Boîte à sons</button>
      <button data-mode="reader">📖 Mode lecture</button><button data-mode="contrast">🌗 Contraste fort</button>
      <button data-mode="text">🔎 Agrandir le texte</button><button data-mode="focus">🧹 Nettoyer la page</button>
      <button data-mode="copy">🔗 Copier le lien</button><button data-mode="note">📝 Prendre une note</button>
      <button data-mode="top">⬆️ Haut de page</button><button data-mode="print">🖨️ Imprimer</button>
      <button data-mode="location">📍 Mini planisphère</button><button data-mode="quicksearch">🔎 Recherche rapide</button>
      <button data-mode="weather">🌦️ Météo express</button><button data-mode="translate">🌐 Traduire en français</button>
      <button data-mode="summary">📚 Résumé de la page</button><button data-mode="define">📖 Définir un mot</button>
      <button data-mode="starwars">🚀 Ouvrir Star Wars</button>
      <button data-mode="pizzamaker">🍕 Composer une pizza</button>
      <button data-mode="musicmaker">🎹 Créer une musique</button>
      <button data-mode="creativelab">🎬 IA vidéo & mini-jeux</button>
      <button data-mode="googleTheme">🎨 Thème du fond Google</button>
      <button data-mode="googleWord">🔤 Changer le mot Google</button>
      <button data-mode="calculator">🧮 Calculatrice rapide</button><button data-mode="checklist">✅ Liste de tâches</button>
      <button data-mode="decision">🎲 Décide pour moi</button><button data-mode="readaloud">🔊 Lire la sélection</button>
      <button data-mode="gradient">🌈 Générateur de dégradé</button>
      <button data-mode="convert">🔁 Convertisseur d’unités</button><button data-mode="stopwatch">⏱️ Chronomètre</button>
      <button data-mode="password">🔐 Générateur de mot de passe</button>
      </div><div class="gadget-empty" hidden>Aucun gadget trouvé. Essaie un autre mot 😺</div>
    </div>
    <button class="dog-button" type="button" aria-label="Ajouter un sticker hot-dog">🌭 Hot-dog</button>
    <button class="pizza-button" type="button" aria-label="Ajouter un sticker pizza">🍕 Pizza</button>
    <button class="clear-button" type="button" hidden>Supprimer les autres</button>
    <button class="stop-button" type="button" hidden>🛑 Tout arrêter</button>
    <div class="movie-modal" hidden>
      <form class="movie-card">
        <h2>🎬 Quelle séance ?</h2><p>Entre un film : je cherche sa bande-annonce sur YouTube.</p>
        <input type="text" name="title" placeholder="Ex. Le Seigneur des anneaux" autocomplete="off" required>
        <div class="movie-actions"><button class="movie-cancel" type="button">Annuler</button><button class="movie-submit" type="submit">Lancer la bande-annonce</button></div>
      </form>
    </div>
    <section class="tool-card" hidden aria-live="polite"><button class="tool-close" type="button">Fermer</button><div class="tool-content"></div></section>
    <section class="pizza-workshop" hidden><div class="pizza-maker"><div class="pizza-head"><h2>🍕 Atelier pizza</h2><button class="pizza-close" type="button">Fermer ✕</button></div><p>Glisse les ingrédients sur la pâte ou clique dessus pour les ajouter.</p><div class="pizza-layout"><div class="ingredient-bins"></div><div class="pizza-dough" role="img" aria-label="Pâte à pizza"><span class="dough-hint">Ta pâte<br>à garnir</span></div></div><div class="pizza-status" aria-live="polite">Choisis tes ingrédients préférés !</div><div class="pizza-actions"><button class="pizza-reset" type="button">Recommencer</button><button class="bake" type="button">🔥 Cuire ma pizza</button></div></div></section>
    <section class="music-workshop" hidden><div class="music-maker"><div class="music-top"><h2>🎹 Mini studio de musique</h2><button class="music-close" type="button">Fermer ✕</button></div><p>Un grand studio pour composer, écouter et télécharger tes idées.</p><div class="music-ai"><strong>✨ Assistant créatif — décris ta musique</strong><small>Écris un thème ou une scène : l’assistant transforme tes mots en une boucle originale. Tout est généré dans ton navigateur.</small><input class="music-prompt" placeholder="Ex. balade magique dans une forêt sous la pluie" aria-label="Thème de la musique"><select class="music-style" aria-label="Ambiance"><option value="auto">✨ Choisir selon le thème</option><option value="chill">🌙 Calme</option><option value="pop">🎈 Pop</option><option value="dance">🪩 Dansante</option><option value="cinema">🚀 Épique</option></select><button class="generate" type="button">✨ Composer</button><input class="music-reference" placeholder="Titre de chanson ou lien musical" aria-label="Titre ou lien musical"><button class="music-reference-generate" type="button">🎼 Créer une version originale</button><small class="inspiration-note">Le titre ou le lien sert seulement de point de départ textuel. La musique distante ne sera ni téléchargée ni copiée.</small></div><div class="music-controls"><label>Tempo <input class="music-tempo" type="range" min="60" max="180" value="110"><span class="tempo-value">110</span> BPM</label><label>Tonalité <select class="music-key" aria-label="Tonalité"><option value="0">Do majeur</option><option value="2">Ré majeur</option><option value="4">Mi majeur</option><option value="5">Fa majeur</option><option value="7">Sol majeur</option><option value="9">La majeur</option><option value="11">Si majeur</option></select></label><label>Volume <input class="music-volume" type="range" min="0" max="1" step="0.01" value="0.8"><span class="volume-value">80%</span></label><label class="music-metronome-label"><input class="music-metronome" type="checkbox"> Métronome</label><span class="music-hint">32 temps · 12 instruments · fais défiler horizontalement pour voir toute la grille</span></div><div class="music-library"><label>Nom du morceau<input class="music-name" maxlength="60" placeholder="Ex. Voyage sur Mars"></label><label>Morceaux sauvegardés<select class="music-saved-list" aria-label="Morceaux sauvegardés"><option value="">Chargement…</option></select></label><button class="music-save" type="button">💾 Sauvegarder</button><button class="music-load" type="button">▶ Charger</button><button class="music-delete" type="button">🗑️ Supprimer</button><p class="music-library-status" aria-live="polite">Les morceaux restent dans le stockage local de cette extension.</p></div><div class="music-grid-wrap"><div class="music-grid"></div></div><div class="music-actions"><button class="play" type="button">▶ Lire</button><button class="music-test" type="button">🔊 Tester le son</button><button class="music-export" type="button">⬇ Télécharger en WAV</button><button class="music-clear" type="button">Effacer</button><button class="voice-button voice-open" type="button">🎙️ Paroles & voix</button></div><section class="voice-panel" hidden aria-label="Paroles et voix"><div class="voice-choices"><button type="button" class="voice-choice" data-voice-mode="synth"><b>🎛️ Voix synthétique</b><span>Choisis une voix disponible sur ton appareil, son timbre et sa vitesse pour lire tes paroles en rythme.</span></button><button type="button" class="voice-choice" data-voice-mode="calibrate"><b>🎤 Calibrer ma voix</b><span>Lis quelques phrases au micro ; l’atelier mesure un aperçu de ta voix et garde les enregistrements en mémoire pour cette session.</span></button></div><div class="voice-mode" data-voice-panel="synth" hidden><div class="voice-note">La synthèse utilise les voix déjà installées dans ton navigateur. Les réglages homme/femme filtrent les voix dont le nom donne un indice ; le choix dépend des voix disponibles sur ton appareil.</div><div class="voice-form"><label>Voix<select class="voice-select" aria-label="Voix de synthèse"></select></label><label>Profil<select class="voice-gender"><option value="all">Toutes les voix</option><option value="female">Voix féminine</option><option value="male">Voix masculine</option></select></label><label>Timbre <span class="voice-pitch-value">1.0</span><input class="voice-pitch" type="range" min="0.5" max="1.8" step="0.1" value="1"></label><label>Vitesse <span class="voice-rate-value">1.0×</span><input class="voice-rate" type="range" min="0.65" max="1.4" step="0.05" value="1"></label></div><textarea class="voice-lyrics" placeholder="Écris les paroles à lire…" aria-label="Paroles à lire"></textarea><div class="voice-actions"><button type="button" class="voice-button primary voice-speak">▶ Lire les paroles</button><button type="button" class="voice-button voice-stop">⏹ Arrêter</button></div><div class="voice-status synth-status" aria-live="polite"></div></div><div class="voice-mode" data-voice-panel="calibrate" hidden><p class="voice-note">Le micro ne s’active qu’après ton clic. Les prises restent en mémoire temporaire dans cette page, ne sont envoyées à aucun serveur et sont effacées à la fermeture du studio. Ce calibrage ne clone pas la voix et ne peut pas encore chanter des paroles avec elle.</p><div class="voice-phrase"></div><div class="voice-meter" aria-label="Niveau sonore du micro"><span></span></div><div class="voice-actions"><button type="button" class="voice-button primary voice-record">🎙️ Enregistrer la phrase</button><button type="button" class="voice-button voice-next">Phrase suivante →</button><button type="button" class="voice-button voice-play-recording" disabled>▶ Écouter ma prise</button></div><div class="voice-status calibration-status" aria-live="polite">Aucune prise enregistrée.</div></div></section><div class="music-status" aria-live="polite">Une boucle de démonstration est prête. Appuie sur Tester le son ou Lire.</div></div></section>
    <div class="stickers"></div>`;

  const addButton = root.querySelector(".dog-button");
  const pizzaButton = root.querySelector(".pizza-button");
  const menuButton = root.querySelector(".menu-button");
  const menu = root.querySelector(".menu");
  const gadgetSearch = root.querySelector(".gadget-search");
  const gadgetButtons = [...root.querySelectorAll(".gadget-grid button[data-mode]")];
  const categoryButtons = [...root.querySelectorAll(".gadget-categories button")];
  let activeCategory = "all";
  const gadgetCategories = {
    confetti: "fun", image: "fun", movie: "search", ducks: "fun", disco: "fun", shake: "fun", toast: "fun", coin: "fun", spotlight: "fun",
    pomodoro: "page", palette: "page", wordcount: "page", soundboard: "fun", reader: "page", contrast: "page", text: "page", focus: "page", copy: "page", note: "page", top: "page", print: "page",
    location: "search", quicksearch: "search", weather: "search", translate: "search", summary: "search", define: "search", starwars: "search", pizzamaker: "fun", musicmaker: "fun", googleTheme: "page", googleWord: "page",
    calculator: "page", checklist: "page", decision: "fun", readaloud: "page", gradient: "page", creativelab: "fun",
    convert: "page", stopwatch: "page", password: "page"
  };
  function filterGadgets() {
    const query = gadgetSearch.value.trim().toLocaleLowerCase("fr");
    let visible = 0;
    gadgetButtons.forEach(button => {
      const matchesText = button.textContent.toLocaleLowerCase("fr").includes(query);
      const matchesCategory = activeCategory === "all" || gadgetCategories[button.dataset.mode] === activeCategory;
      button.hidden = !(matchesText && matchesCategory);
      if (!button.hidden) visible++;
    });
    root.querySelector(".gadget-empty").hidden = visible > 0;
  }
  const clearButton = root.querySelector(".clear-button");
  const stopButton = root.querySelector(".stop-button");
  const movieModal = root.querySelector(".movie-modal");
  const movieForm = root.querySelector(".movie-card");
  const stickerLayer = root.querySelector(".stickers");
  const funLayer = root.querySelector(".fun-layer");
  const toolCard = root.querySelector(".tool-card");
  const toolContent = root.querySelector(".tool-content");
  const pizzaWorkshop = root.querySelector(".pizza-workshop");
  const musicWorkshop = root.querySelector(".music-workshop");
  const musicGrid = root.querySelector(".music-grid");
  const musicTempo = root.querySelector(".music-tempo");
  const tempoValue = root.querySelector(".tempo-value");
  const musicStatus = root.querySelector(".music-status");
  const musicRows = [
    { name: "🥁 Kick", type: "kick" }, { name: "👏 Clap", type: "clap" },
    { name: "✨ Hi-hat fermé", type: "hat" }, { name: "🥁 Snare", type: "snare" },
    { name: "🪇 Shaker", type: "shaker" }, { name: "🎸 Basse", type: "bass" },
    { name: "🔔 Cloche", type: "bell" }, { name: "🎹 Synthé lead", type: "melody" },
    { name: "🪘 Tom", type: "tom" }, { name: "✨ Hi-hat ouvert", type: "openhat" },
    { name: "🎛️ Orgue", type: "organ" }, { name: "🥁 Cymbale", type: "cymbal" }
  ];
  const musicLength = 32;
  const musicKey = root.querySelector(".music-key");
  const musicVolume = root.querySelector(".music-volume");
  const metronomeToggle = root.querySelector(".music-metronome");
  const musicOutputs = new WeakMap();
  const musicOutputList = new Set();
  let currentMusicKey = Number(musicKey.value) || 0;
  let musicMasterVolume = Number(musicVolume.value);
  function musicOutput(context) {
    let output = musicOutputs.get(context);
    if (!output) { output = context.createGain(); output.gain.value = musicMasterVolume; output.connect(context.destination); musicOutputs.set(context, output); if (context === audioContext) musicOutputList.add(output); }
    return output;
  }
  let melodyNotes = Array.from({ length: musicLength }, (_, i) => [261.63, 293.66, 329.63, 392, 440, 392, 329.63, 293.66][i % 8]);
  let musicTimer = null;
  let musicStep = 0;
  musicRows.forEach(({ name }, row) => {
    const label = document.createElement("span"); label.className = "instrument"; label.textContent = name; musicGrid.append(label);
    for (let step = 0; step < musicLength; step++) {
      const cell = document.createElement("button"); cell.type = "button"; cell.className = "step"; cell.setAttribute("aria-label", `${name}, temps ${step + 1}`); cell.dataset.row = row; cell.dataset.step = step;
      cell.addEventListener("click", () => { cell.classList.toggle("on"); }); musicGrid.append(cell);
    }
  });
  function synthesizeMusicNote(context, row, at, step) {
    const type = musicRows[row].type;
    const gain = context.createGain(); gain.connect(musicOutput(context));
    if (["clap", "hat", "snare", "shaker", "openhat", "cymbal"].includes(type)) {
      const duration = type === "shaker" ? .11 : type === "hat" ? .065 : type === "openhat" ? .38 : type === "cymbal" ? .52 : type === "snare" ? .21 : .17;
      const length = Math.floor(context.sampleRate * duration);
      const buffer = context.createBuffer(1, length, context.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
      const noise = context.createBufferSource(); noise.buffer = buffer;
      const filter = context.createBiquadFilter(); filter.type = type === "clap" || type === "snare" ? "bandpass" : "highpass";
      filter.frequency.value = type === "clap" ? 1300 : type === "snare" ? 2200 : type === "hat" ? 7600 : type === "openhat" ? 6800 : type === "cymbal" ? 9200 : 5200;
      noise.connect(filter); filter.connect(gain);
      const volume = type === "clap" ? .24 : type === "snare" ? .3 : type === "hat" ? .11 : type === "openhat" ? .13 : type === "cymbal" ? .12 : .09;
      gain.gain.setValueAtTime(volume, at); gain.gain.exponentialRampToValueAtTime(.001, at + duration);
      noise.start(at); noise.stop(at + duration);
      return;
    }
    const oscillator = context.createOscillator();
    const frequency = type === "kick" ? 125 : type === "tom" ? 190 : type === "bass" ? melodyNotes[step % musicLength] / 4 : type === "bell" ? melodyNotes[step % musicLength] * 2 : melodyNotes[step % musicLength];
    oscillator.type = type === "kick" || type === "tom" || type === "bell" ? "sine" : type === "bass" ? "sawtooth" : type === "organ" ? "square" : "triangle";
    oscillator.frequency.setValueAtTime(frequency, at);
    if (type === "kick") oscillator.frequency.exponentialRampToValueAtTime(42, at + .16);
    if (type === "tom") oscillator.frequency.exponentialRampToValueAtTime(75, at + .16);
    const duration = type === "bell" ? .65 : type === "bass" ? .24 : type === "kick" || type === "tom" ? .2 : type === "organ" ? .42 : .3;
    const volume = type === "kick" ? .5 : type === "bell" ? .18 : type === "bass" ? .22 : type === "organ" ? .12 : .2;
    gain.gain.setValueAtTime(volume, at); gain.gain.exponentialRampToValueAtTime(.001, at + duration);
    oscillator.connect(gain); oscillator.start(at); oscillator.stop(at + duration + .01);
  }
  function playMusicNote(row, step = musicStep) {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) { musicStatus.textContent = "Ce navigateur ne permet pas la synthèse audio WebAudio."; return; }
      audioContext ||= new Ctx();
      synthesizeMusicNote(audioContext, row, audioContext.currentTime, step);
    } catch { /* Audio is optional when the browser blocks it. */ }
  }
  function stopMusic() {
    if (musicTimer) window.clearInterval(musicTimer);
    musicTimer = null; musicGrid.querySelectorAll(".playing").forEach(cell => cell.classList.remove("playing"));
    root.querySelector(".music-workshop .play").textContent = "▶ Lire";
  }
  async function exportMusicWav() {
    const exportButton = root.querySelector(".music-export");
    const OfflineCtx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (!OfflineCtx) { musicStatus.textContent = "L’export audio WAV n’est pas disponible dans ce navigateur."; return; }
    const bpm = Number(musicTempo.value);
    const stepDuration = 60 / bpm / 2;
    const sampleRate = 44100;
    const totalFrames = Math.ceil((stepDuration * musicLength + .5) * sampleRate);
    const pattern = Array.from({ length: musicRows.length }, (_, row) => Array.from({ length: musicLength }, (_, step) => musicGrid.querySelector(`.step[data-row="${row}"][data-step="${step}"]`)?.classList.contains("on")));
    if (!pattern.some(row => row.some(Boolean))) { musicStatus.textContent = "Ajoute au moins une note avant de télécharger la musique."; return; }
    exportButton.disabled = true; exportButton.textContent = "⏳ Préparation…"; musicStatus.textContent = "Création du fichier audio…";
    try {
      const offline = new OfflineCtx(2, totalFrames, sampleRate);
      for (let step = 0; step < musicLength; step++) for (let row = 0; row < musicRows.length; row++) {
        if (!pattern[row][step]) continue;
        const at = step * stepDuration;
        synthesizeMusicNote(offline, row, at, step);
      }
      const rendered = await offline.startRendering();
      const channels = rendered.numberOfChannels; const frames = rendered.length;
      const wav = new ArrayBuffer(44 + frames * channels * 2); const view = new DataView(wav);
      const writeText = (offset, value) => { for (let i = 0; i < value.length; i++) view.setUint8(offset + i, value.charCodeAt(i)); };
      writeText(0, "RIFF"); view.setUint32(4, 36 + frames * channels * 2, true); writeText(8, "WAVE"); writeText(12, "fmt ");
      view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, channels, true); view.setUint32(24, sampleRate, true);
      view.setUint32(28, sampleRate * channels * 2, true); view.setUint16(32, channels * 2, true); view.setUint16(34, 16, true); writeText(36, "data"); view.setUint32(40, frames * channels * 2, true);
      const audioChannels = Array.from({ length: channels }, (_, channel) => rendered.getChannelData(channel));
      let offset = 44;
      for (let frame = 0; frame < frames; frame++) for (let channel = 0; channel < channels; channel++) {
        const sample = Math.max(-1, Math.min(1, audioChannels[channel][frame])); view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true); offset += 2;
      }
      const url = URL.createObjectURL(new Blob([wav], { type: "audio/wav" }));
      const link = document.createElement("a"); link.href = url; link.download = "ma-boucle-musicale.wav"; link.click();
      later(() => URL.revokeObjectURL(url), 3000); musicStatus.textContent = "🎵 Fichier WAV téléchargé ! Tu peux l’ouvrir dans ton lecteur audio.";
    } catch { musicStatus.textContent = "Impossible de créer le fichier audio. Réessaie dans quelques instants."; }
    finally { exportButton.disabled = false; exportButton.textContent = "⬇ Télécharger en WAV"; }
  }
  root.querySelector(".music-export").addEventListener("click", exportMusicWav);
  function playMetronomeClick(accent = false) {
    if (!audioContext) return;
    const oscillator = audioContext.createOscillator(); const gain = audioContext.createGain();
    oscillator.type = "sine"; oscillator.frequency.value = accent ? 1500 : 950;
    gain.gain.setValueAtTime(accent ? .12 : .07, audioContext.currentTime); gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + .045);
    oscillator.connect(gain); gain.connect(musicOutput(audioContext)); oscillator.start(); oscillator.stop(audioContext.currentTime + .05);
  }
  function playMusicStep() {
    const cells = [...musicGrid.querySelectorAll(`.step[data-step="${musicStep}"]`)];
    musicGrid.querySelectorAll(".playing").forEach(cell => cell.classList.remove("playing"));
    cells.forEach(cell => { cell.classList.add("playing"); if (cell.classList.contains("on")) playMusicNote(Number(cell.dataset.row)); });
    if (metronomeToggle.checked && musicStep % 2 === 0) playMetronomeClick(musicStep % 8 === 0);
    musicStep = (musicStep + 1) % musicLength;
  }
  root.querySelector(".music-workshop .play").addEventListener("click", async () => {
    if (musicTimer) { stopMusic(); musicStatus.textContent = "Boucle arrêtée."; return; }
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) { musicStatus.textContent = "La synthèse audio n’est pas disponible dans ce navigateur."; return; }
    try { audioContext ||= new Ctx(); await audioContext.resume(); }
    catch { musicStatus.textContent = "Le navigateur a bloqué le son. Vérifie le volume et les autorisations audio."; return; }
    musicStep = 0; playMusicStep(); musicTimer = window.setInterval(playMusicStep, 60000 / Number(musicTempo.value) / 2);
    root.querySelector(".music-workshop .play").textContent = "⏸ Arrêter"; musicStatus.textContent = "Ta boucle joue en continu !";
  });
  const musicPatterns = {
    chill: [[1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],[1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0],[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],[0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0],[1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0],[1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0]],
    pop: [[1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],[0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],[1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],[0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0],[1,0,0,1,0,0,1,0,1,0,0,1,0,0,1,0]],
    dance: [[1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],[0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],[1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],[0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0],[1,0,1,0,1,0,1,1,1,0,1,0,1,0,1,1]],
    cinema: [[1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],[1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0],[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],[0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0],[1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0],[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]]
  };
  for (const style of Object.keys(musicPatterns)) {
    musicPatterns[style].push(
      style === "dance" ? [1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0] : [1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],
      style === "dance" ? [0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0] : [0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],
      style === "cinema" ? [1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0] : [1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],
      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
    );
    musicPatterns[style] = musicPatterns[style].map(row => Array.from({ length: musicLength }, (_, step) => Boolean(row[step % 16])));
  }
  musicGrid.querySelectorAll(".step").forEach(cell => cell.classList.toggle("on", Boolean(musicPatterns.chill[Number(cell.dataset.row)][Number(cell.dataset.step)])));
  musicKey.addEventListener("change", () => {
    const key = Number(musicKey.value) || 0; const ratio = 2 ** ((key - currentMusicKey) / 12);
    melodyNotes = melodyNotes.map(note => note * ratio); currentMusicKey = key;
    if (musicTimer) { stopMusic(); root.querySelector(".music-workshop .play").click(); }
  });
  musicVolume.addEventListener("input", () => {
    musicMasterVolume = Number(musicVolume.value); root.querySelector(".volume-value").textContent = `${Math.round(musicMasterVolume * 100)}%`;
    musicOutputList.forEach(output => { output.gain.setTargetAtTime(musicMasterVolume, audioContext?.currentTime || 0, .02); });
  });
  root.querySelector(".music-test").addEventListener("click", async () => {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) { musicStatus.textContent = "Audio indisponible dans ce navigateur."; return; }
    try {
      audioContext ||= new Ctx();
      await audioContext.resume();
      musicRows.forEach((track, row) => window.setTimeout(() => playMusicNote(row, row), row * 125));
      musicStatus.textContent = "🔊 Test des 12 pistes : batterie, percussions, basse, synthé, orgue et cymbale.";
    } catch { musicStatus.textContent = "Le son est bloqué : vérifie le volume et les autorisations audio du navigateur."; }
  });
  function referenceDescription(value) {
    try {
      const url = new URL(value);
      const title = ["title", "track", "song", "q", "text"].map(key => url.searchParams.get(key)).find(Boolean);
      if (title) return title.replace(/[+_]/g, " ");
      const pathWords = decodeURIComponent(url.pathname.split("/").filter(Boolean).at(-1) || "").replace(/[-_]/g, " ");
      if (pathWords.length > 8 && !/^(watch|track|album|video)$/i.test(pathWords)) return pathWords;
      const id = url.searchParams.get("v") || url.pathname.split("/").filter(Boolean).at(-1) || url.hostname;
      return `inspiration ${url.hostname} ${id}`;
    } catch { return value; }
  }
  function composeMusicFromTheme(referenceText = "") {
    const typedTheme = root.querySelector(".music-prompt").value.trim();
    const prompt = `${typedTheme} ${referenceText}`.trim().toLocaleLowerCase("fr");
    const requestedStyle = root.querySelector(".music-style").value;
    const style = requestedStyle !== "auto" ? requestedStyle : /dance|électro|electro|bouge|énerg|club|soirée/i.test(prompt) ? "dance" : /épique|epic|ciné|cinema|aventure|spatial|espace|héros|hero/i.test(prompt) ? "cinema" : /pop|joyeux|fun|heureux|soleil|fête|fete/i.test(prompt) ? "pop" : "chill";
    const styleLabel = { chill: "calme", dance: "dansante", cinema: "cinématique", pop: "pop" }[style];
    const baseScale = style === "cinema" ? [220, 261.63, 293.66, 329.63, 392, 440, 523.25] : style === "dance" ? [220, 261.63, 293.66, 329.63, 392, 440, 493.88] : [261.63, 293.66, 329.63, 392, 440, 493.88, 523.25];
    const keyOffset = Number(musicKey.value) || 0; const scale = baseScale.map(frequency => frequency * 2 ** (keyOffset / 12)); currentMusicKey = keyOffset;
    let seed = 2166136261;
    for (const char of (prompt || style)) seed = Math.imul(seed ^ char.charCodeAt(0), 16777619) >>> 0;
    const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
    const beat = musicPatterns[style];
    const pattern = beat.map(row => [...row]);
    for (let step = 0; step < musicLength; step++) {
      pattern[1][step] = style === "dance" ? step % 8 === 4 : step % 8 === 4 && random() > .22;
      pattern[2][step] = style === "dance" ? random() > .13 : random() > (style === "chill" ? .48 : .25);
      pattern[3][step] = step % 8 === 4 || (style !== "chill" && random() > .86);
      pattern[4][step] = random() > (style === "chill" ? .68 : .46);
      pattern[5][step] = step % 8 === 0 || (style === "dance" && step % 8 === 4);
      pattern[6][step] = (step % 4 === 2 || step % 8 === 7) && random() > .35;
      pattern[7][step] = style === "chill" ? step % 4 === 0 || random() > .72 : step % 4 === 0 || random() > .56;
      pattern[8][step] = step % 8 === 6 && random() > .25;
      pattern[9][step] = style === "dance" ? step % 4 === 2 : random() > .78;
      pattern[10][step] = step % 16 === 0 || (style === "cinema" && step % 16 === 8);
      pattern[11][step] = step % 16 === 15;
      melodyNotes[step] = scale[Math.floor(random() * scale.length)] * (random() > .82 ? 2 : 1);
    }
    musicGrid.querySelectorAll(".step").forEach(cell => cell.classList.toggle("on", Boolean(pattern[Number(cell.dataset.row)][Number(cell.dataset.step)])));
    musicTempo.value = style === "chill" ? 84 + Math.floor(random() * 15) : style === "dance" ? 122 + Math.floor(random() * 17) : style === "cinema" ? 88 + Math.floor(random() * 25) : 102 + Math.floor(random() * 21);
    tempoValue.textContent = musicTempo.value;
    if (musicTimer) { stopMusic(); root.querySelector(".music-workshop .play").click(); }
    musicStatus.textContent = `✨ Boucle originale ${styleLabel} composée ${prompt ? `à partir de « ${prompt.slice(0, 55)}${prompt.length > 55 ? "…" : ""} »` : ""}. Elle s’inspire du texte seulement ; la source musicale n’est ni écoutée ni copiée.`;
  }
  root.querySelector(".music-ai .generate").addEventListener("click", () => composeMusicFromTheme());
  root.querySelector(".music-reference-generate").addEventListener("click", () => {
    const reference = root.querySelector(".music-reference").value.trim();
    if (!reference) { musicStatus.textContent = "Saisis le titre d’une chanson ou un lien pour t’en inspirer."; root.querySelector(".music-reference").focus(); return; }
    composeMusicFromTheme(referenceDescription(reference));
  });
  const voicePanel = root.querySelector(".voice-panel");
  const voiceSelect = root.querySelector(".voice-select");
  const voiceGender = root.querySelector(".voice-gender");
  const voiceLyrics = root.querySelector(".voice-lyrics");
  const voiceStatus = root.querySelector(".synth-status");
  const calibrationStatus = root.querySelector(".calibration-status");
  const voicePhrase = root.querySelector(".voice-phrase");
  const voicePhrases = [
    "Trois très grands trains traversent tranquillement la prairie.",
    "Sacha sèche six chaussettes sur le vieux séchoir.",
    "Un joli rouge-gorge chante près du grand chêne.",
    "Paul pose peu à peu plusieurs petits papiers pliés.",
    "Fanny fait frémir les feuilles fines du figuier.",
    "La pluie brille, puis le vent emporte les dernières feuilles."
  ];
  let phraseIndex = 0;
  let voiceTakes = [];
  let voiceStream = null;
  let voiceRecorder = null;
  let voiceChunks = [];
  let voiceMeterFrame = 0;
  let voiceAnalyser = null;
  let voiceSource = null;
  let voiceCaptureContext = null;
  let voicePitchTotal = 0;
  let voicePitchSamples = 0;
  let voiceRecordingStarted = 0;
  function getAvailableVoices() {
    return window.speechSynthesis?.getVoices?.() || [];
  }
  function refreshVoiceOptions() {
    const voices = getAvailableVoices().filter(voice => voice.lang.toLocaleLowerCase().startsWith("fr"));
    const profile = voiceGender.value;
    const filtered = profile === "all" ? voices : voices.filter(voice => {
      const name = voice.name.toLocaleLowerCase();
      const female = /female|femme|woman|am[eé]lie|marie|julie|audrey|hortense|victoria|samantha|zira|elsa|denise|lea|léa/.test(name);
      const male = /male|homme|man|thomas|henri|paul|jacques|david|antoine|daniel|george|guy/.test(name);
      return profile === "female" ? female : male;
    });
    const selected = voiceSelect.value;
    voiceSelect.replaceChildren();
    (filtered.length ? filtered : voices).forEach(voice => {
      const option = document.createElement("option"); option.value = voice.name; option.textContent = `${voice.name}${voice.default ? " · défaut" : ""}`; voiceSelect.append(option);
    });
    if (selected && [...voiceSelect.options].some(option => option.value === selected)) voiceSelect.value = selected;
    if (!voiceSelect.options.length) { const option = document.createElement("option"); option.textContent = "Aucune voix française détectée"; voiceSelect.append(option); }
  }
  root.querySelector(".voice-open").addEventListener("click", () => {
    voicePanel.hidden = !voicePanel.hidden;
    if (!voicePanel.hidden) refreshVoiceOptions();
  });
  voiceGender.addEventListener("change", refreshVoiceOptions);
  window.speechSynthesis?.addEventListener?.("voiceschanged", refreshVoiceOptions);
  refreshVoiceOptions();
  root.querySelectorAll(".voice-choice").forEach(button => button.addEventListener("click", () => {
    root.querySelectorAll(".voice-mode").forEach(panel => { panel.hidden = panel.dataset.voicePanel !== button.dataset.voiceMode; });
    if (button.dataset.voiceMode === "calibrate") voicePhrase.textContent = voicePhrases[phraseIndex % voicePhrases.length];
    if (button.dataset.voiceMode === "synth") refreshVoiceOptions();
  }));
  const pitchControl = root.querySelector(".voice-pitch");
  const rateControl = root.querySelector(".voice-rate");
  pitchControl.addEventListener("input", () => { root.querySelector(".voice-pitch-value").textContent = Number(pitchControl.value).toFixed(1); });
  rateControl.addEventListener("input", () => { root.querySelector(".voice-rate-value").textContent = `${Number(rateControl.value).toFixed(2).replace(/0$/, "")}×`; });
  root.querySelector(".voice-speak").addEventListener("click", () => {
    const speech = window.speechSynthesis;
    const text = voiceLyrics.value.trim();
    if (!speech || !window.SpeechSynthesisUtterance) { voiceStatus.textContent = "La synthèse vocale n’est pas disponible dans ce navigateur."; return; }
    if (!text) { voiceStatus.textContent = "Écris d’abord quelques paroles."; voiceLyrics.focus(); return; }
    speech.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "fr-FR"; utterance.rate = Number(rateControl.value); utterance.pitch = Number(pitchControl.value);
    utterance.voice = getAvailableVoices().find(voice => voice.name === voiceSelect.value) || null;
    utterance.onstart = () => { voiceStatus.textContent = "🔊 Lecture des paroles avec la voix sélectionnée…"; };
    utterance.onend = () => { voiceStatus.textContent = "Lecture terminée. Ajuste le timbre ou la vitesse et réécoute."; };
    utterance.onerror = () => { voiceStatus.textContent = "La lecture vocale a été interrompue par le navigateur."; };
    speech.speak(utterance);
  });
  root.querySelector(".voice-stop").addEventListener("click", () => { window.speechSynthesis?.cancel(); voiceStatus.textContent = "Lecture arrêtée."; });
  function stopVoiceCapture() {
    if (voiceMeterFrame) cancelAnimationFrame(voiceMeterFrame);
    voiceMeterFrame = 0;
    if (voiceRecorder?.state === "recording") voiceRecorder.stop();
    voiceStream?.getTracks().forEach(track => track.stop()); voiceStream = null;
    try { voiceSource?.disconnect(); voiceAnalyser?.disconnect(); } catch { /* Already disconnected. */ }
    voiceSource = null; voiceAnalyser = null;
    if (voiceCaptureContext && voiceCaptureContext.state !== "closed") voiceCaptureContext.close().catch(() => {});
    voiceCaptureContext = null;
    root.querySelector(".voice-meter span").style.width = "0%";
  }
  function updateVoiceMeter() {
    if (!voiceAnalyser || voiceRecorder?.state !== "recording") return;
    const data = new Float32Array(voiceAnalyser.fftSize); voiceAnalyser.getFloatTimeDomainData(data);
    let sum = 0, crossings = 0;
    for (let i = 0; i < data.length; i++) { sum += data[i] * data[i]; if (i && data[i - 1] <= 0 && data[i] > 0) crossings++; }
    const rms = Math.sqrt(sum / data.length);
    root.querySelector(".voice-meter span").style.width = `${Math.min(100, Math.max(3, rms * 420))}%`;
    const hz = crossings * voiceCaptureContext.sampleRate / data.length;
    if (rms > .012 && hz > 65 && hz < 500) { voicePitchTotal += hz; voicePitchSamples++; }
    voiceMeterFrame = requestAnimationFrame(updateVoiceMeter);
  }
  root.querySelector(".voice-record").addEventListener("click", async event => {
    const button = event.currentTarget;
    if (voiceRecorder?.state === "recording") { voiceRecorder.stop(); button.textContent = "🎙️ Enregistrer la phrase"; return; }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) { calibrationStatus.textContent = "L’enregistrement du micro n’est pas disponible dans ce navigateur ou cette page."; return; }
    button.disabled = true; calibrationStatus.textContent = "Demande d’autorisation du micro…";
    try {
      voiceStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      voiceChunks = []; voicePitchTotal = 0; voicePitchSamples = 0; voiceRecordingStarted = performance.now();
      voiceRecorder = new MediaRecorder(voiceStream);
      voiceRecorder.ondataavailable = e => { if (e.data.size) voiceChunks.push(e.data); };
      voiceRecorder.onstop = () => {
        const duration = Math.max(1, Math.round((performance.now() - voiceRecordingStarted) / 1000));
        const blob = new Blob(voiceChunks, { type: voiceRecorder.mimeType || "audio/webm" });
        voiceTakes.push({ phrase: voicePhrase.textContent, blob, duration, pitch: voicePitchSamples ? Math.round(voicePitchTotal / voicePitchSamples) : null });
        root.querySelector(".voice-play-recording").disabled = false;
        const pitch = voicePitchSamples ? ` Hauteur approximative détectée : ${Math.round(voicePitchTotal / voicePitchSamples)} Hz.` : " Parle près du micro pour obtenir une estimation de hauteur.";
        calibrationStatus.textContent = `✅ Prise ${voiceTakes.length} enregistrée (${duration} s) en mémoire temporaire.${pitch}`;
        phraseIndex = (phraseIndex + 1) % voicePhrases.length; voicePhrase.textContent = voicePhrases[phraseIndex];
        button.textContent = "🎙️ Enregistrer la phrase"; button.disabled = false; stopVoiceCapture();
      };
      voiceCaptureContext = new (window.AudioContext || window.webkitAudioContext)();
      voiceAnalyser = voiceCaptureContext.createAnalyser(); voiceAnalyser.fftSize = 2048;
      voiceSource = voiceCaptureContext.createMediaStreamSource(voiceStream); voiceSource.connect(voiceAnalyser);
      voiceRecorder.start(); button.textContent = "⏹ Arrêter la prise"; button.disabled = false;
      calibrationStatus.textContent = "🔴 Enregistrement en cours. Lis la phrase à voix haute, puis arrête la prise.";
      updateVoiceMeter();
    } catch (error) {
      button.disabled = false; stopVoiceCapture();
      calibrationStatus.textContent = error?.name === "NotAllowedError" ? "Accès au micro refusé. Autorise le micro dans le navigateur pour continuer." : "Impossible de démarrer le micro. Vérifie qu’il est branché et autorisé.";
    }
  });
  root.querySelector(".voice-next").addEventListener("click", () => { phraseIndex = (phraseIndex + 1) % voicePhrases.length; voicePhrase.textContent = voicePhrases[phraseIndex]; });
  root.querySelector(".voice-play-recording").addEventListener("click", () => {
    const take = voiceTakes.at(-1); if (!take) return;
    const url = URL.createObjectURL(take.blob); const audio = new Audio(url);
    audio.onended = () => URL.revokeObjectURL(url); audio.onerror = () => URL.revokeObjectURL(url);
    audio.play().catch(() => { URL.revokeObjectURL(url); calibrationStatus.textContent = "La lecture de la prise a été bloquée par le navigateur."; });
  });
  musicTempo.addEventListener("input", () => { tempoValue.textContent = musicTempo.value; if (musicTimer) { stopMusic(); root.querySelector(".music-workshop .play").click(); } });
  root.querySelector(".music-clear").addEventListener("click", () => { musicGrid.querySelectorAll(".step").forEach(cell => cell.classList.remove("on")); musicStatus.textContent = "Grille effacée. Compose une nouvelle boucle !"; });
  const musicName = root.querySelector(".music-name");
  const savedMusicList = root.querySelector(".music-saved-list");
  const musicLibraryStatus = root.querySelector(".music-library-status");
  const musicStorageKey = "gadjetsnathanMusicLibrary";
  function readSavedMusic() {
    return new Promise((resolve, reject) => {
      if (!chrome.storage?.local) { reject(new Error("Le stockage local de l’extension est indisponible.")); return; }
      chrome.storage.local.get(musicStorageKey, result => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else resolve(Array.isArray(result[musicStorageKey]) ? result[musicStorageKey] : []);
      });
    });
  }
  function writeSavedMusic(library) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.set({ [musicStorageKey]: library }, () => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message)); else resolve();
      });
    });
  }
  async function refreshMusicLibrary(selectedId = savedMusicList.value) {
    try {
      const library = await readSavedMusic();
      savedMusicList.replaceChildren();
      const placeholder = document.createElement("option"); placeholder.value = ""; placeholder.textContent = library.length ? `Choisir un morceau (${library.length})` : "Aucun morceau sauvegardé"; savedMusicList.append(placeholder);
      library.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)).forEach(song => {
        const option = document.createElement("option"); option.value = song.id; option.textContent = song.name; savedMusicList.append(option);
      });
      if (library.some(song => song.id === selectedId)) savedMusicList.value = selectedId;
      root.querySelector(".music-load").disabled = !library.length;
      root.querySelector(".music-delete").disabled = !library.length;
      musicLibraryStatus.textContent = library.length ? `${library.length} morceau${library.length > 1 ? "x" : ""} sauvegardé${library.length > 1 ? "s" : ""} sur cet appareil.` : "Aucun morceau pour l’instant. Donne un nom à ta boucle puis sauvegarde-la.";
      return library;
    } catch (error) {
      musicLibraryStatus.textContent = `Impossible d’accéder au stockage local : ${error.message}`;
      root.querySelector(".music-load").disabled = true; root.querySelector(".music-delete").disabled = true;
      return [];
    }
  }
  root.querySelector(".music-save").addEventListener("click", async () => {
    const name = musicName.value.trim();
    if (!name) { musicLibraryStatus.textContent = "Écris un nom pour ton morceau avant de le sauvegarder."; musicName.focus(); return; }
    const saveButton = root.querySelector(".music-save"); saveButton.disabled = true;
    try {
      const library = await readSavedMusic();
      const existing = library.find(song => song.name.toLocaleLowerCase("fr") === name.toLocaleLowerCase("fr"));
      const pattern = Array.from({ length: musicRows.length }, (_, row) => Array.from({ length: musicLength }, (_, step) => musicGrid.querySelector(`.step[data-row="${row}"][data-step="${step}"]`)?.classList.contains("on") || false));
      const song = { id: existing?.id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, name, tempo: Number(musicTempo.value), key: Number(musicKey.value) || 0, pattern, melody: [...melodyNotes], updatedAt: Date.now() };
      const updated = existing ? library.map(item => item.id === existing.id ? song : item) : [...library, song];
      await writeSavedMusic(updated); await refreshMusicLibrary(song.id);
      musicLibraryStatus.textContent = `💾 « ${name} » sauvegardé sur cet appareil.`;
    } catch (error) { musicLibraryStatus.textContent = `La sauvegarde a échoué : ${error.message}`; }
    finally { saveButton.disabled = false; }
  });
  savedMusicList.addEventListener("change", async () => {
    const song = (await refreshMusicLibrary()).find(item => item.id === savedMusicList.value);
    if (song) musicName.value = song.name;
  });
  root.querySelector(".music-load").addEventListener("click", async () => {
    const library = await refreshMusicLibrary();
    const song = library.find(item => item.id === savedMusicList.value);
    if (!song) { musicLibraryStatus.textContent = "Choisis d’abord un morceau dans la liste."; return; }
    if (musicTimer) stopMusic();
    musicGrid.querySelectorAll(".step").forEach(cell => { const row = Number(cell.dataset.row), step = Number(cell.dataset.step); cell.classList.toggle("on", Boolean(song.pattern?.[row]?.[step])); });
    melodyNotes = Array.from({ length: musicLength }, (_, step) => Number(song.melody?.[step]) || 261.63);
    musicTempo.value = Math.max(60, Math.min(180, Number(song.tempo) || 110)); tempoValue.textContent = musicTempo.value;
    musicKey.value = String(Number(song.key) || 0); currentMusicKey = Number(musicKey.value);
    musicName.value = song.name; musicStatus.textContent = `🎵 « ${song.name} » chargée !`; musicLibraryStatus.textContent = "Morceau chargé. Tu peux le modifier puis le sauvegarder à nouveau.";
  });
  root.querySelector(".music-delete").addEventListener("click", async () => {
    const id = savedMusicList.value;
    if (!id) { musicLibraryStatus.textContent = "Choisis un morceau dans la liste avant de le supprimer."; return; }
    try {
      const library = await readSavedMusic(); const removed = library.find(song => song.id === id);
      await writeSavedMusic(library.filter(song => song.id !== id)); musicName.value = "";
      await refreshMusicLibrary(""); musicLibraryStatus.textContent = `🗑️ « ${removed?.name || "Morceau"} » supprimé.`;
    } catch (error) { musicLibraryStatus.textContent = `La suppression a échoué : ${error.message}`; }
  });
  refreshMusicLibrary();
  root.querySelector(".music-close").addEventListener("click", () => { stopMusic(); window.speechSynthesis?.cancel(); if (voiceRecorder?.state === "recording") { voiceRecorder.onstop = null; voiceRecorder.stop(); } stopVoiceCapture(); voiceTakes = []; musicWorkshop.hidden = true; });
  const pizzaDough = root.querySelector(".pizza-dough");
  const pizzaBins = root.querySelector(".ingredient-bins");
  const pizzaStatus = root.querySelector(".pizza-status");
  const pizzaIngredients = [["🍅", "Tomate"], ["🧀", "Fromage"], ["🍄", "Champignon"], ["🫒", "Olive"], ["🌶️", "Poivron"], ["🍍", "Ananas"], ["🥓", "Jambon"], ["🌿", "Basilic"]];
  function addPizzaTopping(emoji) {
    const topping = document.createElement("span"); topping.className = "topping"; topping.textContent = emoji;
    topping.style.left = `${12 + Math.random() * 76}%`; topping.style.top = `${12 + Math.random() * 76}%`;
    pizzaDough.append(topping); pizzaDough.querySelector(".dough-hint")?.remove();
    pizzaStatus.textContent = `${emoji} ajouté ! Continue à garnir ta pizza.`; playPop();
  }
  pizzaIngredients.forEach(([emoji, name]) => {
    const bin = document.createElement("button"); bin.type = "button"; bin.className = "ingredient-bin"; bin.draggable = true; bin.dataset.emoji = emoji; bin.setAttribute("aria-label", name);
    const symbol = document.createElement("span"); symbol.textContent = emoji;
    const label = document.createElement("small"); label.textContent = name;
    bin.append(symbol, label); bin.addEventListener("dragstart", event => event.dataTransfer.setData("text/plain", emoji));
    bin.addEventListener("click", () => addPizzaTopping(emoji)); pizzaBins.append(bin);
  });
  pizzaDough.addEventListener("dragover", event => { event.preventDefault(); pizzaDough.classList.add("drag-over"); });
  pizzaDough.addEventListener("dragleave", () => pizzaDough.classList.remove("drag-over"));
  pizzaDough.addEventListener("drop", event => { event.preventDefault(); pizzaDough.classList.remove("drag-over"); const emoji = event.dataTransfer.getData("text/plain"); if (pizzaIngredients.some(item => item[0] === emoji)) addPizzaTopping(emoji); });
  root.querySelector(".pizza-close").addEventListener("click", () => { pizzaWorkshop.hidden = true; });
  pizzaWorkshop.addEventListener("click", event => { if (event.target === pizzaWorkshop) pizzaWorkshop.hidden = true; });
  root.querySelector(".pizza-reset").addEventListener("click", () => {
    pizzaDough.querySelectorAll(".topping").forEach(item => item.remove());
    if (!pizzaDough.querySelector(".dough-hint")) { const hint = document.createElement("span"); hint.className = "dough-hint"; hint.innerHTML = "Ta pâte<br>à garnir"; pizzaDough.append(hint); }
    pizzaStatus.textContent = "Pâte remise à zéro : à toi de jouer !";
  });
  root.querySelector(".bake").addEventListener("click", () => {
    const count = pizzaDough.querySelectorAll(".topping").length;
    pizzaStatus.textContent = count ? `🔥 Ta pizza est cuite avec ${count} ingrédient${count > 1 ? "s" : ""} ! Bon appétit !` : "Ajoute d'abord quelques ingrédients sur la pâte !";
    if (count) playPop();
  });
  const runningIntervals = new Map();
  const runningTimeouts = new Set();
  let audioContext;

  function autoOpenTrailerFromResults() {
    if (location.hostname !== "www.youtube.com" || location.pathname !== "/results" || location.hash !== "#hack-trailer-autoplay") return;
    const deadline = Date.now() + 18000;
    const poll = window.setInterval(() => {
      if (location.hash !== "#hack-trailer-autoplay" || Date.now() > deadline) { window.clearInterval(poll); return; }
      const links = [...document.querySelectorAll('a#video-title[href*="/watch"]')];
      if (!links.length) return;
      const titleText = link => link.innerText || link.getAttribute("title") || "";
      const frenchTrailer = links.find(link => /trailer|bande.?annonce/i.test(titleText(link)) && /\b(vf|français|française|french|version française)\b/i.test(titleText(link)));
      const firstTrailer = frenchTrailer || links.find(link => /trailer|bande.?annonce/i.test(titleText(link))) || links[0];
      const target = new URL(firstTrailer.href, location.href);
      target.searchParams.set("autoplay", "1");
      window.clearInterval(poll);
      location.replace(target.href);
    }, 400);
  }
  autoOpenTrailerFromResults();

  function autoLaunchMovieSearch() {
    if (!/(^|\.)google\.(com|fr)$/.test(location.hostname) || location.pathname !== "/search") return;
    const query = new URL(location.href).searchParams.get("q")?.trim();
    if (!query || query.toLowerCase() === "/hack" || query.length > 100) return;
    const key = `hackTrailerSearch:${query.toLowerCase()}`;
    if (sessionStorage.getItem(key)) return;
    const started = Date.now();
    const inspect = window.setInterval(() => {
      if (Date.now() - started > 9000) { window.clearInterval(inspect); return; }
      const panelText = (document.querySelector("#rhs")?.innerText || document.body.innerText || "").toLowerCase();
      const asksForTrailer = /bande.?annonce|trailer/.test(query.toLowerCase());
      const hasFilmLabel = /\b(film|movie|long.métrage|cinéma)\b/.test(panelText);
      const hasFilmFacts = /réalisateur|director|casting|distribution|acteurs|sortie|release date|genre|\d+\s?h\s?\d+|\d+\s?minutes/.test(panelText);
      const hasTrailerResult = /bande.?annonce|trailer officiel|official trailer/.test(panelText);
      if (!asksForTrailer && !(hasFilmLabel && (hasFilmFacts || hasTrailerResult))) return;
      window.clearInterval(inspect);
      sessionStorage.setItem(key, "1");
      chrome.runtime.sendMessage({ type: "open-movie-trailer", title: query });
    }, 500);
  }
  autoLaunchMovieSearch();

  function later(callback, delay) {
    const timer = window.setTimeout(() => { runningTimeouts.delete(timer); callback(); }, delay);
    runningTimeouts.add(timer);
    return timer;
  }

  function playPop() {
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;
      audioContext ||= new AudioContextClass();
      if (audioContext.state === "suspended") audioContext.resume();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      const now = audioContext.currentTime;
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(620, now);
      oscillator.frequency.exponentialRampToValueAtTime(180, now + 0.09);
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.24, now + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
      oscillator.connect(gain); gain.connect(audioContext.destination);
      oscillator.start(now); oscillator.stop(now + 0.13);
    } catch { /* Audio is optional if the browser blocks it. */ }
  }

  function showStopButton() { stopButton.hidden = false; }

  function addSticker(emoji = "🌭", label = "Sticker hot-dog") {
    if (typeof emoji !== "string") emoji = "🌭";
    const sticker = document.createElement("div");
    sticker.className = "sticker"; sticker.setAttribute("role", "img");
    sticker.setAttribute("aria-label", label); sticker.textContent = emoji;
    const margin = 100;
    sticker.style.left = `${margin + Math.random() * Math.max(0, innerWidth - margin * 2)}px`;
    sticker.style.top = `${margin + Math.random() * Math.max(0, innerHeight - margin * 2)}px`;
    sticker.style.setProperty("--tilt", `${Math.round(Math.random() * 40 - 20)}deg`);
    stickerLayer.appendChild(sticker); clearButton.hidden = false; showStopButton(); playPop();
  }

  function removeStickers(immediate = false) {
    const stickers = [...stickerLayer.children];
    if (immediate) {
      stickers.forEach(sticker => sticker.remove());
      clearButton.hidden = true;
      return;
    }
    stickers.forEach(sticker => sticker.classList.add("out"));
    later(() => { stickers.forEach(sticker => sticker.remove()); clearButton.hidden = stickerLayer.children.length === 0; }, 190);
  }

  function dropEmoji(emoji) {
    const item = document.createElement("span");
    item.className = "confetti"; item.textContent = emoji;
    item.style.left = `${Math.random() * 100}vw`;
    item.style.setProperty("--fall", `${2 + Math.random() * 2.4}s`);
    funLayer.appendChild(item); later(() => item.remove(), 4600);
  }

  const sillyMessages = ["Le canard approuve ta navigation.", "404 : sérieux introuvable.", "Chargement du fromage…", "Ton curseur a l'air très occupé.", "Tout va bien. Probablement."];
  const randomImages = [
    ["🐸", "grenouille cool", "#a9f59d"], ["🐱", "chat en mission", "#ffc6df"],
    ["🛸", "visiteur spatial", "#b9e8ff"], ["🍕", "pizza cosmique", "#ffd28a"],
    ["🦖", "mini dinosaure", "#b9ef9d"], ["🧙", "mage du dimanche", "#d6baff"],
    ["🥔", "patate héroïque", "#e5c99a"], ["🐙", "octopus de poche", "#ffb9d4"],
    ["🦆", "canard officiel", "#fff08c"], ["🌈", "arc-en-ciel surprise", "#baf6e8"]
  ];
  const globalEffects = document.createElement("style");
  globalEffects.id = "hack-hotdog-page-effects";
  globalEffects.textContent = "@keyframes hackHotdogShake{0%,100%{transform:translate(0,0)}25%{transform:translate(2px,-1px)}50%{transform:translate(-2px,1px)}75%{transform:translate(1px,2px)}}html.hack-hotdog-shake{animation:hackHotdogShake .14s infinite!important}";
  const pageModes = new Map();
  let googleLogoState = [];
  const pageStyle = document.createElement("style");
  pageStyle.id = "hack-hotdog-utility-modes";
  pageStyle.textContent = `
    html.hack-reader{background:#f4f0e6!important;color:#25231f!important;font-size:19px!important;line-height:1.75!important}
    html.hack-reader body{max-width:900px!important;margin:24px auto!important;padding:28px!important;background:#fffdf7!important;color:#25231f!important;font-family:Georgia,serif!important}
    html.hack-contrast{filter:contrast(1.55) saturate(1.2)!important}
    html.hack-text{zoom:1.2!important}
    html.hack-focus *{visibility:hidden!important}
    html.hack-focus #hack-hotdog-extension,html.hack-focus #hack-hotdog-extension *,html.hack-focus main,html.hack-focus article,html.hack-focus [role="main"],html.hack-focus [role="article"]{visibility:visible!important}
    html.hack-focus main,html.hack-focus article,html.hack-focus [role="main"],html.hack-focus [role="article"]{position:relative!important;z-index:2147483000!important;max-width:900px!important;margin:30px auto!important;padding:24px!important;background:white!important;color:#222!important;box-shadow:0 4px 30px #0003!important}
  `;

  function togglePageMode(mode, className) {
    const enabled = !document.documentElement.classList.contains(className);
    document.documentElement.classList.toggle(className, enabled);
    pageModes.set(mode, enabled);
    if (pageModes.size) document.head.appendChild(pageStyle);
    else pageStyle.remove();
    showStopButton();
  }

  async function copyPageLink() {
    try {
      await navigator.clipboard.writeText(location.href);
      const toast = document.createElement("div"); toast.className = "toast"; toast.textContent = "Lien copié !";
      funLayer.appendChild(toast); later(() => toast.remove(), 1800); showStopButton();
    } catch {
      window.prompt("Copie ce lien :", location.href);
    }
  }

  function takePageNote() {
    const note = window.prompt("Ta note pour cette page (elle sera téléchargée en .txt) :", "");
    if (note === null) return;
    const blob = new Blob([`Note — ${document.title}\n${location.href}\n\n${note}\n`], { type: "text/plain;charset=utf-8" });
    const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = "note-page.txt"; link.click();
    later(() => URL.revokeObjectURL(link.href), 1000);
  }

  function restoreGoogleWord() {
    for (const item of googleLogoState) {
      item.overlay.remove();
      item.node.style.visibility = item.visibility;
      if (item.hadAriaHidden) item.node.setAttribute("aria-hidden", item.ariaHidden); else item.node.removeAttribute("aria-hidden");
      item.parent.style.position = item.parentPosition;
    }
    googleLogoState = [];
  }

  function googleWordGadget() {
    const box = document.createElement("div");
    const description = document.createElement("p"); description.textContent = "Remplace le logo Google par le mot de ton choix en gardant les lettres multicolores et un style proche du logo.";
    const row = document.createElement("div"); row.className = "tool-row";
    const input = document.createElement("input"); input.maxLength = 24; input.placeholder = "Ex. Nathan, Miaou, Pizza…"; input.setAttribute("aria-label", "Nouveau texte du logo Google");
    const apply = document.createElement("button"); apply.textContent = "Changer le logo";
    const reset = document.createElement("button"); reset.textContent = "Rétablir Google";
    const status = document.createElement("p"); status.setAttribute("aria-live", "polite");
    function applyWord() {
      if (!/(^|\.)google\.(com|fr)$/.test(location.hostname)) { status.textContent = "Ouvre Google pour utiliser ce gadget."; return; }
      const word = input.value.trim();
      if (!word) { status.textContent = "Écris un mot ou un petit nom."; input.focus(); return; }
      restoreGoogleWord();
      const selectors = ['#logo', '#lga', '#hplogo', '[aria-label="Google"]', '[title="Google"]', 'img[alt*="Google"]', 'svg[aria-label*="Google"]', '#logo img', '#lga img'];
      let logo = null;
      for (const selector of selectors) {
        logo = [...document.querySelectorAll(selector)].find(node => {
          const rect = node.getBoundingClientRect();
          const style = getComputedStyle(node);
          return rect.width >= 80 && rect.height >= 20 && style.display !== "none" && style.visibility !== "hidden";
        });
        if (logo) break;
      }
      if (!logo) { status.textContent = "Je ne trouve pas le logo Google. Essaie depuis la page d’accueil Google."; return; }
      const colors = ["#4285F4", "#EA4335", "#FBBC05", "#4285F4", "#34A853", "#EA4335"];
      const parent = logo.parentElement || logo;
      const rect = logo.getBoundingClientRect();
      const parentRect = parent.getBoundingClientRect();
      const overlay = document.createElement("span"); overlay.setAttribute("role", "img"); overlay.setAttribute("aria-label", word);
      const fontSize = Math.max(16, Math.min(82, rect.height * 0.78, rect.width / (Array.from(word).length * 0.62)));
      overlay.style.cssText = `position:absolute;left:${rect.left - parentRect.left}px;top:${rect.top - parentRect.top}px;width:${rect.width}px;height:${rect.height}px;display:flex;align-items:center;justify-content:center;white-space:nowrap;overflow:hidden;z-index:5;font-family:'Product Sans',Arial,sans-serif;font-size:${fontSize}px;font-weight:500;letter-spacing:-.055em;line-height:1;pointer-events:none`;
      Array.from(word).forEach((character, index) => { const letter = document.createElement("span"); letter.textContent = character; letter.style.color = colors[index % colors.length]; overlay.append(letter); });
      googleLogoState.push({ node: logo, parent, overlay, visibility: logo.style.visibility, hadAriaHidden: logo.hasAttribute("aria-hidden"), ariaHidden: logo.getAttribute("aria-hidden"), parentPosition: parent.style.position });
      logo.style.visibility = "hidden"; logo.setAttribute("aria-hidden", "true");
      if (getComputedStyle(parent).position === "static") parent.style.position = "relative";
      parent.appendChild(overlay);
      status.textContent = `✨ « ${word} » remplace maintenant le logo. Le changement reste sur cette page.`;
      showStopButton();
    }
    apply.addEventListener("click", applyWord);
    input.addEventListener("keydown", event => { if (event.key === "Enter") applyWord(); });
    reset.addEventListener("click", () => { restoreGoogleWord(); status.textContent = "Logo Google d’origine rétabli."; });
    row.append(input, apply, reset); box.append(description, row, status);
    openTool("🔤 Changer le mot Google", box);
    if (!/(^|\.)google\.(com|fr)$/.test(location.hostname)) status.textContent = "Ce gadget fonctionne quand tu es sur Google.";
  }

  function googleThemeGadget() {
    const box = document.createElement("div");
    const description = document.createElement("p"); description.textContent = "Saisis une couleur, une ambiance ou colle l’URL d’une image. Sur Google, tu peux aussi choisir un thème ci-dessous.";
    const row = document.createElement("div"); row.className = "tool-row";
    const input = document.createElement("input"); input.placeholder = "Ex. bleu, océan, forêt…"; input.setAttribute("aria-label", "Couleur, thème ou URL d’image");
    const apply = document.createElement("button"); apply.textContent = "Appliquer";
    const status = document.createElement("p"); status.setAttribute("aria-live", "polite");
    const presets = document.createElement("div"); presets.className = "tool-row";
    const backgrounds = {
      ocean: "https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1920&q=85",
      forest: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1920&q=85",
      sunset: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1920&q=85",
      space: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1920&q=85",
      beach: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=85"
    };
    const colorWords = { bleu: "#75baff", rose: "#f5a6c8", violet: "#9c8ade", vert: "#8bcf9b", jaune: "#ffe27a", noir: "#171923", blanc: "#ffffff", orange: "#ffad62", rouge: "#f08080", turquoise: "#68d7d0" };
    function applyTheme() {
      if (!/(^|\.)google\.(com|fr)$/.test(location.hostname)) { status.textContent = "Ouvre Google pour appliquer ce thème."; return; }
      const value = input.value.trim();
      if (!value) { status.textContent = "Saisis une couleur, un thème ou une URL d’image."; return; }
      const normalized = value.toLocaleLowerCase("fr").replace(/^image\s*:\s*/, "").trim();
      const themeWords = { ocean: /océan|ocean|mer/, forest: /forêt|foret|bois|nature/, sunset: /coucher|soleil|sunset/, space: /espace|univers|galaxie|étoile|etoile/, beach: /plage|mer turquoise/ };
      let imageUrl = null;
      for (const [key, pattern] of Object.entries(themeWords)) if (pattern.test(normalized)) imageUrl = backgrounds[key];
      if (!imageUrl && /^https?:\/\//i.test(value)) {
        try { const parsed = new URL(value); if (["http:", "https:"].includes(parsed.protocol)) imageUrl = parsed.href; } catch { /* URL invalide */ }
      }
      const color = colorWords[normalized] || (window.CSS?.supports("color", value) ? value : null);
      if (!imageUrl && !color) { status.textContent = "Mot inconnu : essaie une couleur, océan, forêt, plage, espace, coucher de soleil ou colle un lien d’image."; return; }
      let style = document.getElementById("hack-google-background-theme");
      if (!style) { style = document.createElement("style"); style.id = "hack-google-background-theme"; document.head.append(style); }
      const background = imageUrl ? `url("${imageUrl}")` : color;
      style.textContent = `body{background:${background} center / cover fixed no-repeat!important;min-height:100vh!important}`;
      status.textContent = imageUrl ? "Image de fond appliquée. Recharge Google pour la retrouver après navigation." : `Fond ${normalized} appliqué.`;
    }
    apply.addEventListener("click", applyTheme);
    input.addEventListener("keydown", event => { if (event.key === "Enter") applyTheme(); });
    [["🌊 Océan", "océan"], ["🌲 Forêt", "forêt"], ["🌇 Coucher de soleil", "coucher de soleil"], ["🌌 Espace", "espace"], ["🏖️ Plage", "plage"]].forEach(([label, value]) => {
      const button = document.createElement("button"); button.textContent = label; button.addEventListener("click", () => { input.value = value; applyTheme(); }); presets.append(button);
    });
    row.append(input, apply);
    const reset = document.createElement("button"); reset.textContent = "Rétablir le fond Google";
    reset.addEventListener("click", () => { document.getElementById("hack-google-background-theme")?.remove(); status.textContent = "Fond Google d’origine rétabli."; });
    box.append(description, row, presets, reset, status);
    openTool("🎨 Thème Google", box);
    if (!/(^|\.)google\.(com|fr)$/.test(location.hostname)) status.textContent = "Ce gadget s’applique quand tu es sur Google.";
  }

  function openTool(title, content) {
    toolContent.replaceChildren();
    const heading = document.createElement("h2"); heading.textContent = title; toolContent.append(heading, content);
    toolCard.hidden = false; showStopButton();
  }

  function locationGadget() {
    const box = document.createElement("div");
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || "Fuseau inconnu";
    let place = "Position approximative via le fuseau horaire";
    if (/Paris|Brussels|Amsterdam|Luxembourg|Monaco/i.test(timezone)) place = "Europe occidentale · secteur de Paris (approx.)";
    else if (/London|Dublin/i.test(timezone)) place = "Europe · secteur de Londres (approx.)";
    else if (/Tokyo|Seoul/i.test(timezone)) place = "Asie de l’Est (approx.)";
    else if (/New_York|Toronto|Detroit/i.test(timezone)) place = "Amérique du Nord · Est (approx.)";
    const map = document.createElement("div"); map.className = "map";
    const pin = document.createElement("span"); pin.className = "map-pin"; pin.textContent = "📍";
    const coords = /Paris|Brussels|Amsterdam|London|Dublin|Europe/i.test(timezone) ? ["47%", "39%"] : /Tokyo|Seoul/i.test(timezone) ? ["77%", "43%"] : /New_York|Toronto|Detroit/i.test(timezone) ? ["27%", "40%"] : ["52%", "45%"];
    pin.style.setProperty("--x", coords[0]); pin.style.setProperty("--y", coords[1]); map.append(pin);
    const info = document.createElement("p"); info.textContent = `${place} — ${timezone}. Ce n’est pas une position GPS.`;
    const clock = document.createElement("p");
    const update = () => clock.textContent = `🕒 Heure locale : ${new Intl.DateTimeFormat("fr-FR", { timeZone: timezone, dateStyle: "medium", timeStyle: "medium" }).format(new Date())}`;
    update(); const timer = window.setInterval(update, 1000); runningIntervals.set("local-clock", timer);
    box.append(map, info, clock); openTool("📍 Mini planisphère", box);
  }

  function quickSearchGadget() {
    const box = document.createElement("div");
    const input = document.createElement("input"); input.placeholder = "Que veux-tu chercher ?";
    const choices = document.createElement("div"); choices.className = "tool-row";
    [["Google", "https://www.google.com/search?q="], ["YouTube", "https://www.youtube.com/results?search_query="], ["Maps", "https://www.google.com/maps/search/"]].forEach(([label, base]) => {
      const button = document.createElement("button"); button.textContent = `Rechercher sur ${label}`;
      button.addEventListener("click", () => { const query = input.value.trim(); if (query) window.open(base + encodeURIComponent(query), "_blank", "noopener"); }); choices.append(button);
    });
    box.append(input, choices); openTool("🔎 Recherche rapide", box); input.focus();
  }

  function soundboardGadget() {
    const box = document.createElement("div");
    const intro = document.createElement("p"); intro.textContent = "Une petite boîte à rythmes : clique sur les pads pour jouer un son.";
    const pads = document.createElement("div"); pads.className = "tool-row";
    const status = document.createElement("p"); status.setAttribute("aria-live", "polite");
    [["🥁 Kick", 0], ["👏 Clap", 1], ["🥁 Snare", 3], ["🪘 Tom", 8], ["🔔 Cloche", 6], ["🎹 Note", 7], ["🎛️ Orgue", 10], ["✨ Cymbale", 11]].forEach(([label, row]) => {
      const pad = document.createElement("button"); pad.textContent = label;
      pad.addEventListener("click", async () => {
        try { const Ctx = window.AudioContext || window.webkitAudioContext; if (!Ctx) throw new Error("Audio indisponible"); audioContext ||= new Ctx(); await audioContext.resume(); playMusicNote(Number(row), Math.floor(Math.random() * musicLength)); status.textContent = `${label} joué !`; }
        catch { status.textContent = "Le son est bloqué. Vérifie le volume du navigateur."; }
      }); pads.append(pad);
    });
    box.append(intro, pads, status); openTool("🎛️ Boîte à sons", box);
  }

  function weatherGadget() {
    const box = document.createElement("div");
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || "local";
    const text = document.createElement("p"); text.textContent = "Cherche la météo de la ville ou du lieu que tu saisis :";
    const row = document.createElement("div"); row.className = "tool-row";
    const input = document.createElement("input"); input.placeholder = "Ville";
    const button = document.createElement("button"); button.textContent = "Voir la météo";
    button.addEventListener("click", () => { const city = input.value.trim(); if (city) window.open(`https://www.google.com/search?q=${encodeURIComponent(`météo ${city}`)}`, "_blank", "noopener"); });
    const hint = document.createElement("small"); hint.textContent = `Fuseau de cet appareil : ${timezone}`;
    row.append(input, button); box.append(text, row, hint); openTool("🌦️ Météo express", box); input.focus();
  }

  function pomodoroGadget() {
    const box = document.createElement("div");
    const intro = document.createElement("p"); intro.textContent = "Choisis une durée, lance le chrono et concentre-toi. Le compte à rebours reste dans cette page.";
    const row = document.createElement("div"); row.className = "tool-row";
    const minutes = document.createElement("input"); minutes.type = "number"; minutes.min = "1"; minutes.max = "90"; minutes.value = "25"; minutes.setAttribute("aria-label", "Durée en minutes");
    const start = document.createElement("button"); start.textContent = "Démarrer";
    const status = document.createElement("p"); status.setAttribute("aria-live", "polite"); status.textContent = "25:00";
    start.addEventListener("click", () => {
      if (runningIntervals.has("pomodoro")) { clearInterval(runningIntervals.get("pomodoro")); runningIntervals.delete("pomodoro"); start.textContent = "Démarrer"; status.textContent = "Minuteur arrêté."; return; }
      const duration = Math.max(1, Math.min(90, Number(minutes.value) || 25)) * 60;
      const deadline = Date.now() + duration * 1000; start.textContent = "Arrêter";
      const tick = () => { const left = Math.max(0, Math.ceil((deadline - Date.now()) / 1000)); status.textContent = `⏱️ ${String(Math.floor(left / 60)).padStart(2, "0")}:${String(left % 60).padStart(2, "0")}`; if (!left) { clearInterval(runningIntervals.get("pomodoro")); runningIntervals.delete("pomodoro"); start.textContent = "Démarrer"; status.textContent = "🎉 Temps écoulé ! Fais une petite pause."; playPop(); } };
      tick(); runningIntervals.set("pomodoro", window.setInterval(tick, 250)); showStopButton();
    });
    row.append(minutes, start); box.append(intro, row, status); openTool("⏱️ Minuteur Pomodoro", box);
  }

  function paletteGadget() {
    const box = document.createElement("div");
    const intro = document.createElement("p"); intro.textContent = "Clique sur une couleur pour copier son code hexadécimal.";
    const palette = document.createElement("div"); palette.className = "tool-row";
    const status = document.createElement("p"); status.setAttribute("aria-live", "polite");
    ["#FF6B6B", "#FF9F1C", "#FFD166", "#06D6A0", "#2EC4B6", "#4D96FF", "#6C63FF", "#B967FF", "#F15BB5", "#F7F7FF", "#A0AEC0", "#20212C"].forEach(color => {
      const swatch = document.createElement("button"); swatch.textContent = color; swatch.style.background = color; swatch.style.color = ["#F7F7FF", "#FFD166", "#A0AEC0"].includes(color) ? "#222" : "#111"; swatch.setAttribute("aria-label", `Copier la couleur ${color}`);
      swatch.addEventListener("click", async () => { try { await navigator.clipboard.writeText(color); status.textContent = `${color} copié !`; } catch { window.prompt("Copie ce code couleur :", color); } }); palette.append(swatch);
    });
    box.append(intro, palette, status); openTool("🎨 Palette de couleurs", box);
  }

  function wordCounterGadget() {
    const box = document.createElement("div");
    const intro = document.createElement("p"); intro.textContent = "Colle du texte ou récupère la sélection de la page. L’analyse reste locale.";
    const textarea = document.createElement("textarea"); textarea.rows = 6; textarea.style.cssText = "width:100%;box-sizing:border-box;background:#29263c;color:white;border:1px solid #ffffff35;border-radius:9px;padding:10px;font:inherit"; textarea.value = window.getSelection()?.toString().trim() || "";
    const stats = document.createElement("p"); stats.setAttribute("aria-live", "polite");
    const count = () => { const text = textarea.value.trim(); const words = text ? text.split(/\s+/u).length : 0; stats.textContent = `📝 ${words} mot${words > 1 ? "s" : ""} · ${textarea.value.length} caractères · environ ${Math.max(1, Math.ceil(words / 200))} min de lecture`; };
    textarea.addEventListener("input", count); count(); box.append(intro, textarea, stats); openTool("🔢 Compteur de mots", box); textarea.focus();
  }

  function translateGadget() {
    const selected = window.getSelection()?.toString().trim();
    const text = selected || document.title;
    window.open(`https://translate.google.com/?sl=auto&tl=fr&text=${encodeURIComponent(text)}&op=translate`, "_blank", "noopener");
  }

  function creativeLabGadget() {
    const box = document.createElement("div"), intro = document.createElement("p"), idea = document.createElement("textarea"), tabs = document.createElement("div"), gameTab = document.createElement("button"), videoTab = document.createElement("button"), gamePanel = document.createElement("section"), videoPanel = document.createElement("section");
    intro.textContent = "Décris ton idée : crée un petit jeu immédiatement dans la page, ou prépare un prompt pour un générateur vidéo IA.";
    idea.value = "Un petit jeu rapide où il faut attraper des étoiles dans l’espace."; idea.rows = 3; idea.setAttribute("aria-label", "Idée de création");
    idea.style.cssText = "width:100%;box-sizing:border-box;padding:12px;border-radius:10px;background:#29263c;color:white;border:1px solid #ffffff35;font:inherit;resize:vertical";
    tabs.className = "tool-row"; gameTab.textContent = "🕹️ Mini-jeu"; videoTab.textContent = "🎥 Vidéo IA"; gamePanel.style.marginTop = videoPanel.style.marginTop = "12px";
    const gameNote = document.createElement("small"); gameNote.textContent = "Le jeu rapide est généré et joué localement dans cette page. Pour demander un jeu plus complexe à une IA, utilise le bouton d’assistance.";
    const generate = document.createElement("button"); generate.textContent = "✨ Générer mon mini-jeu";
    const askAi = document.createElement("button"); askAi.textContent = "🤖 Demander un jeu plus complet à ChatGPT";
    const game = document.createElement("div"); game.style.cssText = "display:none;margin-top:12px;padding:12px;border-radius:12px;background:#11101b";
    const gameTitle = document.createElement("h3"), scoreText = document.createElement("p"), arena = document.createElement("div"), target = document.createElement("button"), gameStatus = document.createElement("p"), start = document.createElement("button");
    gameTitle.textContent = "🌟 Attrape les étoiles !"; scoreText.textContent = "Score : 0 · Temps : 20 s"; gameStatus.textContent = "Appuie sur Démarrer puis clique sur l’émoji qui bouge."; start.textContent = "▶ Démarrer";
    arena.style.cssText = "position:relative;height:220px;overflow:hidden;border:1px solid #ffffff30;border-radius:12px;background:radial-gradient(circle at 50% 50%,#303268,#11101b 72%)";
    target.textContent = "⭐"; target.setAttribute("aria-label", "Cible du mini-jeu"); target.style.cssText = "position:absolute;left:45%;top:40%;font-size:32px;border:0;border-radius:50%;background:#ffffff20;cursor:pointer;min-width:50px;min-height:50px"; target.hidden = true;
    let score = 0, seconds = 20, active = false;
    const renderScore = () => { scoreText.textContent = `Score : ${score} · Temps : ${seconds} s`; };
    const stopGame = message => { if (runningIntervals.has("creativelab-game")) { clearInterval(runningIntervals.get("creativelab-game")); runningIntervals.delete("creativelab-game"); } active = false; target.hidden = true; start.textContent = "▶ Rejouer"; gameStatus.textContent = message; };
    target.addEventListener("click", event => { event.stopPropagation(); if (!active) return; score++; renderScore(); const maxX = Math.max(0, arena.clientWidth - target.offsetWidth), maxY = Math.max(0, arena.clientHeight - target.offsetHeight); target.style.left = `${Math.random() * maxX}px`; target.style.top = `${Math.random() * maxY}px`; });
    start.addEventListener("click", () => { if (active) { stopGame("Partie arrêtée. Tu peux rejouer quand tu veux."); return; } score = 0; seconds = 20; active = true; target.hidden = false; start.textContent = "⏹ Arrêter"; gameStatus.textContent = "C’est parti ! Clique vite sur la cible."; renderScore(); const tick = () => { seconds--; renderScore(); if (seconds <= 0) { stopGame(`⏱️ Terminé ! Score final : ${score}.`); playPop(); } }; runningIntervals.set("creativelab-game", window.setInterval(tick, 1000)); showStopButton(); });
    generate.addEventListener("click", () => { const text = idea.value.toLocaleLowerCase("fr"); const targetEmoji = /pizza|fromage|tomate/.test(text) ? "🍕" : /hot.?dog|saucisse/.test(text) ? "🌭" : /chat|chaton|miaou/.test(text) ? "🐱" : /cœur|coeur|amour/.test(text) ? "💖" : /planète|espace|étoile|etoile|fusée/.test(text) ? "🌟" : "🎯"; target.textContent = targetEmoji; target.setAttribute("aria-label", `Cible ${targetEmoji}`); game.style.display = "block"; gameTitle.textContent = `${targetEmoji} ${idea.value.trim().slice(0, 54) || "Attrape la cible !"}`; gameStatus.textContent = "Ton idée a été transformée en jeu de réflexes local. Appuie sur Démarrer."; stopGame("Prêt à jouer !"); });
    const chatPrompt = () => `Crée un mini-jeu complet en HTML, CSS et JavaScript, dans un seul fichier, à partir de cette idée : ${idea.value.trim() || "un petit jeu amusant"}. Le jeu doit être jouable au clavier et à la souris, adapté au mobile, avoir un score et un bouton recommencer. Retourne seulement le code HTML.`;
    askAi.addEventListener("click", async () => { window.open("https://chatgpt.com/", "_blank", "noopener"); try { await navigator.clipboard.writeText(chatPrompt()); gameStatus.textContent = "Le prompt est copié : colle-le dans ChatGPT pour obtenir un jeu complet."; } catch { window.prompt("Copie ce prompt dans ChatGPT :", chatPrompt()); } });
    game.append(gameTitle, scoreText, arena, gameStatus, start); arena.append(target);
    const videoNote = document.createElement("p"); videoNote.textContent = "Le bouton ouvre Google Flow dans un nouvel onglet et copie ton prompt. Le service génère la vidéo ; son accès et ses fonctions varient selon le pays et le compte Google.";
    const style = document.createElement("select"); style.setAttribute("aria-label", "Style vidéo"); [["cinematic", "🎬 Cinématographique"], ["animation", "🧸 Animation"], ["documentary", "📽️ Documentaire"], ["fantasy", "🐉 Fantastique"], ["music", "🎵 Clip musical"]].forEach(([value, label]) => { const option = document.createElement("option"); option.value = value; option.textContent = label; style.append(option); });
    const videoButton = document.createElement("button"); videoButton.textContent = "🎥 Préparer et ouvrir Flow";
    const videoStatus = document.createElement("p"); videoStatus.setAttribute("aria-live", "polite");
    const makeVideoPrompt = () => `Crée une courte vidéo de style ${style.selectedOptions[0]?.textContent || "cinématographique"}, inspirée de cette idée : ${idea.value.trim() || "une scène originale"}. Décris une scène visuellement claire, un sujet, une action, le décor, la lumière et un mouvement de caméra fluide. Format 16:9, sans texte incrusté.`;
    videoButton.addEventListener("click", async () => { window.open("https://labs.google/fx/tools/flow", "_blank", "noopener"); try { await navigator.clipboard.writeText(makeVideoPrompt()); videoStatus.textContent = "Prompt vidéo copié : colle-le dans Google Flow."; } catch { window.prompt("Copie ce prompt dans Google Flow :", makeVideoPrompt()); } });
    videoPanel.append(style, videoNote, videoButton, videoStatus); gamePanel.append(gameNote, generate, askAi, game);
    const showMode = mode => { gamePanel.hidden = mode !== "game"; videoPanel.hidden = mode !== "video"; gameTab.setAttribute("aria-pressed", String(mode === "game")); videoTab.setAttribute("aria-pressed", String(mode === "video")); };
    gameTab.addEventListener("click", () => showMode("game")); videoTab.addEventListener("click", () => showMode("video")); tabs.append(gameTab, videoTab);
    box.append(intro, idea, tabs, gamePanel, videoPanel); showMode("game"); openTool("🎬 Atelier IA vidéo & mini-jeux", box); idea.focus();
  }

  function calculatorGadget() {
    const box = document.createElement("div"), input = document.createElement("input"), result = document.createElement("p"), hint = document.createElement("small");
    input.placeholder = "Ex. (12 + 8) * 3 / 2"; input.setAttribute("aria-label", "Calcul"); input.style.cssText = "width:100%;box-sizing:border-box;padding:12px;border-radius:9px;background:#29263c;color:white;border:1px solid #ffffff35;font:inherit";
    result.setAttribute("aria-live", "polite"); hint.textContent = "Calcul local : nombres et opérations + − × ÷, parenthèses et décimales.";
    const calculate = () => { const expression = input.value.trim(); if (!expression) { result.textContent = "Entre un calcul."; return; } if (!/^[\d+*/().,%\s-]+$/.test(expression)) { result.textContent = "Caractère non autorisé dans ce calcul."; return; } try { const value = Function(`"use strict"; return (${expression.replace(/,/g, ".")})`)(); result.textContent = Number.isFinite(value) ? `= ${Number(value.toFixed(8))}` : "Résultat non valide."; } catch { result.textContent = "Vérifie les parenthèses et les opérations."; } };
    input.addEventListener("input", calculate); input.addEventListener("keydown", event => { if (event.key === "Enter") calculate(); }); box.append(input, result, hint); openTool("🧮 Calculatrice rapide", box); input.focus();
  }

  function checklistGadget() {
    const box = document.createElement("div"), input = document.createElement("input"), add = document.createElement("button"), list = document.createElement("div"), status = document.createElement("small"), key = "gadjetsnathan-tasks";
    input.placeholder = "Nouvelle tâche…"; input.setAttribute("aria-label", "Nouvelle tâche"); add.textContent = "Ajouter"; list.style.cssText = "display:grid;gap:8px;margin:12px 0";
    let tasks = []; try { tasks = JSON.parse(localStorage.getItem(key) || "[]"); if (!Array.isArray(tasks)) tasks = []; } catch {}
    const save = () => { try { localStorage.setItem(key, JSON.stringify(tasks)); status.textContent = "Liste enregistrée sur cet appareil."; } catch { status.textContent = "Stockage local indisponible."; } };
    const render = () => { list.replaceChildren(); tasks.forEach((task, i) => { const row = document.createElement("label"), check = document.createElement("input"), text = document.createElement("span"), remove = document.createElement("button"); row.style.cssText = "display:flex;align-items:center;gap:9px;padding:9px;border-radius:9px;background:#ffffff12"; check.type = "checkbox"; check.checked = !!task.done; text.textContent = task.text; text.style.cssText = `flex:1;${task.done ? "text-decoration:line-through;opacity:.6" : ""}`; remove.textContent = "✕"; remove.setAttribute("aria-label", "Supprimer la tâche"); check.addEventListener("change", () => { tasks[i].done = check.checked; save(); render(); }); remove.addEventListener("click", () => { tasks.splice(i, 1); save(); render(); }); row.append(check, text, remove); list.append(row); }); };
    const addTask = () => { const text = input.value.trim(); if (!text) return; tasks.push({ text, done: false }); input.value = ""; save(); render(); }; add.addEventListener("click", addTask); input.addEventListener("keydown", event => { if (event.key === "Enter") addTask(); }); box.append(input, add, list, status); render(); openTool("✅ Liste de tâches", box);
  }

  function decisionGadget() {
    const box = document.createElement("div"), intro = document.createElement("p"), choices = document.createElement("textarea"), button = document.createElement("button"), answer = document.createElement("h3");
    intro.textContent = "Écris une option par ligne, puis laisse le hasard choisir."; choices.rows = 5; choices.value = "Pizza\nBurger\nSushi"; choices.setAttribute("aria-label", "Options du tirage"); choices.style.cssText = "width:100%;box-sizing:border-box;padding:10px;border-radius:9px;background:#29263c;color:white;border:1px solid #ffffff35;font:inherit"; button.textContent = "🎲 Choisir au hasard"; answer.setAttribute("aria-live", "polite");
    button.addEventListener("click", () => { const options = choices.value.split(/\r?\n/).map(value => value.trim()).filter(Boolean); answer.textContent = options.length ? `👉 ${options[Math.floor(Math.random() * options.length)]}` : "Ajoute au moins une option."; }); box.append(intro, choices, button, answer); openTool("🎲 Décide pour moi", box);
  }

  function readSelectionGadget() {
    const selected = window.getSelection()?.toString().trim(), text = selected || document.querySelector("main, article, [role='main']")?.innerText?.slice(0, 1200) || document.title;
    if (!window.speechSynthesis) { openTool("🔊 Lire la sélection", document.createTextNode("La lecture vocale n’est pas disponible dans ce navigateur.")); return; }
    window.speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(text); utterance.lang = "fr-FR"; window.speechSynthesis.speak(utterance); openTool("🔊 Lecture en cours", Object.assign(document.createElement("p"), { textContent: selected ? "Lecture de ton texte sélectionné." : "Aucun texte sélectionné : lecture du début de l’article." })); showStopButton();
  }

  function gradientGadget() {
    const box = document.createElement("div"), a = document.createElement("input"), b = document.createElement("input"), angle = document.createElement("input"), preview = document.createElement("div"), css = document.createElement("code"), copy = document.createElement("button");
    a.type = b.type = "color"; a.value = "#7657ff"; b.value = "#ff78b7"; angle.type = "range"; angle.min = "0"; angle.max = "360"; angle.value = "135"; angle.setAttribute("aria-label", "Angle du dégradé"); preview.style.cssText = "height:120px;border-radius:14px;margin:12px 0"; copy.textContent = "📋 Copier le CSS";
    const update = () => { const value = `linear-gradient(${angle.value}deg, ${a.value}, ${b.value})`; preview.style.background = value; css.textContent = `background: ${value};`; }; [a, b, angle].forEach(el => el.addEventListener("input", update)); copy.addEventListener("click", async () => { try { await navigator.clipboard.writeText(css.textContent); copy.textContent = "Copié !"; } catch { window.prompt("Copie le CSS :", css.textContent); } }); update(); box.append(a, b, angle, preview, css, copy); openTool("🌈 Générateur de dégradé", box);
  }

  function convertGadget() {
    const box = document.createElement("div"), value = document.createElement("input"), from = document.createElement("select"), to = document.createElement("select"), result = document.createElement("h3"), row = document.createElement("div");
    const units = [
      { name: "mètres", family: "distance", factor: 1 }, { name: "kilomètres", family: "distance", factor: 1000 }, { name: "centimètres", family: "distance", factor: .01 }, { name: "miles", family: "distance", factor: 1609.344 },
      { name: "grammes", family: "masse", factor: 1 }, { name: "kilogrammes", family: "masse", factor: 1000 }, { name: "livres", family: "masse", factor: 453.59237 },
      { name: "°C", family: "température" }, { name: "°F", family: "température" }
    ];
    value.type = "number"; value.step = "any"; value.value = "1"; value.setAttribute("aria-label", "Valeur à convertir");
    for (const unit of units) for (const select of [from, to]) { const option = document.createElement("option"); option.value = unit.name; option.textContent = unit.name; select.append(option); }
    from.value = "mètres"; to.value = "kilomètres"; row.className = "tool-row"; row.append(value, from, document.createTextNode("→"), to); result.setAttribute("aria-live", "polite");
    const update = () => { const amount = Number(value.value), a = units.find(unit => unit.name === from.value), b = units.find(unit => unit.name === to.value); if (!Number.isFinite(amount)) { result.textContent = "Entre une valeur."; return; } if (a.family !== b.family) { result.textContent = "Choisis deux unités de la même famille."; return; } let converted; if (a.family === "température") converted = from.value === to.value ? amount : from.value === "°C" ? amount * 9 / 5 + 32 : (amount - 32) * 5 / 9; else converted = amount * a.factor / b.factor; result.textContent = `= ${Number(converted.toPrecision(8))} ${b.name}`; };
    [value, from, to].forEach(el => el.addEventListener("input", update)); update(); box.append(row, result, Object.assign(document.createElement("small"), { textContent: "Conversions simples, calculées localement dans ton navigateur." })); openTool("🔁 Convertisseur d’unités", box);
  }

  function stopwatchGadget() {
    const box = document.createElement("div"), display = document.createElement("h2"), start = document.createElement("button"), lap = document.createElement("button"), reset = document.createElement("button"), laps = document.createElement("ol");
    let startedAt = 0, elapsed = 0, marks = 0; display.textContent = "00:00.0"; display.style.cssText = "font-size:38px;text-align:center;font-variant-numeric:tabular-nums"; start.textContent = "▶ Démarrer"; lap.textContent = "🏁 Tour"; reset.textContent = "↺ Réinitialiser"; lap.disabled = true; reset.disabled = true;
    const format = ms => `${String(Math.floor(ms / 60000)).padStart(2,"0")}:${String(Math.floor(ms / 1000) % 60).padStart(2,"0")}.${Math.floor(ms / 100) % 10}`;
    const stopTimer = () => { const timer = runningIntervals.get("stopwatch"); if (timer) clearInterval(timer); runningIntervals.delete("stopwatch"); elapsed += Date.now() - startedAt; start.textContent = "▶ Reprendre"; };
    start.addEventListener("click", () => { if (runningIntervals.has("stopwatch")) { stopTimer(); return; } startedAt = Date.now(); start.textContent = "⏸ Pause"; lap.disabled = reset.disabled = false; runningIntervals.set("stopwatch", window.setInterval(() => { display.textContent = format(elapsed + Date.now() - startedAt); }, 50)); showStopButton(); });
    lap.addEventListener("click", () => { if (!runningIntervals.has("stopwatch")) return; const mark = elapsed + Date.now() - startedAt; marks++; const item = document.createElement("li"); item.textContent = `Tour ${marks} — ${format(mark)}`; laps.prepend(item); });
    reset.addEventListener("click", () => { if (runningIntervals.has("stopwatch")) stopTimer(); elapsed = 0; marks = 0; display.textContent = "00:00.0"; laps.replaceChildren(); start.textContent = "▶ Démarrer"; lap.disabled = reset.disabled = true; });
    box.append(display, Object.assign(document.createElement("div"), { className: "tool-row" })); box.lastChild.append(start, lap, reset); box.append(laps); openTool("⏱️ Chronomètre", box);
  }

  function passwordGadget() {
    const box = document.createElement("div"), length = document.createElement("input"), lengthLabel = document.createElement("label"), generate = document.createElement("button"), output = document.createElement("input"), copy = document.createElement("button"), note = document.createElement("small");
    length.type = "number"; length.min = "8"; length.max = "64"; length.value = "20"; length.setAttribute("aria-label", "Longueur du mot de passe"); lengthLabel.textContent = "Longueur (8 à 64 caractères) "; lengthLabel.append(length); generate.textContent = "🔐 Générer"; output.readOnly = true; output.placeholder = "Ton mot de passe apparaîtra ici"; output.setAttribute("aria-label", "Mot de passe généré"); output.style.cssText = "width:100%;box-sizing:border-box;padding:12px;margin:10px 0;border-radius:9px;background:#29263c;color:white;border:1px solid #ffffff35;font:inherit"; copy.textContent = "📋 Copier"; note.textContent = "Généré localement, jamais envoyé ni sauvegardé par l’extension.";
    generate.addEventListener("click", () => { const size = Math.max(8, Math.min(64, Number(length.value) || 20)), chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*-_+?"; const bytes = new Uint8Array(size); crypto.getRandomValues(bytes); output.value = Array.from(bytes, byte => chars[byte % chars.length]).join(""); });
    copy.addEventListener("click", async () => { if (!output.value) return; try { await navigator.clipboard.writeText(output.value); copy.textContent = "Copié !"; } catch { output.select(); document.execCommand("copy"); copy.textContent = "Copié !"; } }); box.append(lengthLabel, generate, output, copy, document.createElement("br"), note); openTool("🔐 Générateur de mot de passe", box);
  }

  let spotlightMoveHandler = null;
  function toggleMode(mode) {
    if (runningIntervals.has(mode)) {
      clearInterval(runningIntervals.get(mode)); runningIntervals.delete(mode);
      if (mode === "disco") root.querySelector(".disco")?.remove();
      if (mode === "shake") { document.documentElement.classList.remove("hack-hotdog-shake"); globalEffects.remove(); }
      if (mode === "spotlight") { root.querySelector(".spotlight")?.remove(); if (spotlightMoveHandler) document.removeEventListener("pointermove", spotlightMoveHandler); spotlightMoveHandler = null; }
      showStopButton(); return;
    }
    showStopButton();
    if (mode === "confetti" || mode === "coin") {
      const emoji = mode === "coin" ? "🪙" : ["🎉", "✨", "⭐", "🎊"][Math.floor(Math.random() * 4)];
      for (let i = 0; i < 46; i++) later(() => dropEmoji(emoji), i * 32);
      later(() => { if (!runningIntervals.size && !stickerLayer.children.length) stopButton.hidden = true; }, 6800);
    } else if (mode === "ducks") {
      const parade = () => { const duck = document.createElement("div"); duck.className = "duck"; duck.textContent = "🦆"; duck.style.setProperty("--y", `${8 + Math.random() * 78}vh`); funLayer.appendChild(duck); later(() => duck.remove(), 6200); };
      parade(); runningIntervals.set(mode, window.setInterval(parade, 900));
    } else if (mode === "disco") {
      const disco = document.createElement("div"); disco.className = "disco"; funLayer.appendChild(disco);
      runningIntervals.set(mode, window.setInterval(() => {}, 60000));
    } else if (mode === "shake") {
      document.head.appendChild(globalEffects); document.documentElement.classList.add("hack-hotdog-shake");
      runningIntervals.set(mode, window.setInterval(() => {}, 60000));
    } else if (mode === "spotlight") {
      const light = document.createElement("div"); light.className = "spotlight"; funLayer.appendChild(light);
      spotlightMoveHandler = event => { light.style.setProperty("--x", `${event.clientX}px`); light.style.setProperty("--y", `${event.clientY}px`); };
      document.addEventListener("pointermove", spotlightMoveHandler, { passive: true });
      runningIntervals.set(mode, window.setInterval(() => {}, 60000));
    } else if (mode === "toast") {
      const toast = () => { const note = document.createElement("div"); note.className = "toast"; note.textContent = sillyMessages[Math.floor(Math.random() * sillyMessages.length)]; funLayer.appendChild(note); later(() => note.remove(), 2300); };
      toast(); runningIntervals.set(mode, window.setInterval(toast, 2800));
    }
  }

  function stopEverything() {
    for (const timer of runningIntervals.values()) clearInterval(timer);
    runningIntervals.clear(); funLayer.replaceChildren();
    if (spotlightMoveHandler) document.removeEventListener("pointermove", spotlightMoveHandler); spotlightMoveHandler = null;
    for (const timer of runningTimeouts) clearTimeout(timer);
    runningTimeouts.clear();
    removeStickers(true);
    document.documentElement.classList.remove("hack-hotdog-shake"); globalEffects.remove();
    for (const className of ["hack-reader", "hack-contrast", "hack-text", "hack-focus"]) document.documentElement.classList.remove(className);
    pageModes.clear(); pageStyle.remove();
    document.getElementById("hack-google-background-theme")?.remove();
    restoreGoogleWord();
    toolCard.hidden = true;
    pizzaWorkshop.hidden = true;
    stopMusic(); window.speechSynthesis?.cancel(); if (voiceRecorder?.state === "recording") { voiceRecorder.onstop = null; voiceRecorder.stop(); } stopVoiceCapture(); voiceTakes = []; musicWorkshop.hidden = true;
    stopButton.hidden = true; menu.hidden = true; menuButton.setAttribute("aria-expanded", "false");
  }

  function spawnRandomImage() {
    const [emoji, caption, color] = randomImages[Math.floor(Math.random() * randomImages.length)];
    const image = document.createElement("div");
    image.className = "random-image";
    image.setAttribute("role", "img");
    image.setAttribute("aria-label", caption);
    image.style.left = `${Math.max(8, Math.random() * (innerWidth - 155))}px`;
    image.style.top = `${Math.max(8, Math.random() * (innerHeight - 165))}px`;
    image.style.setProperty("--tilt", `${Math.round(Math.random() * 24 - 12)}deg`);
    image.style.setProperty("--card", color);
    image.innerHTML = `<span>${emoji}</span><small>${caption}</small>`;
    funLayer.appendChild(image);
    showStopButton();
    playPop();
    later(() => {
      image.remove();
      if (!funLayer.querySelector(".random-image") && !runningIntervals.size && !stickerLayer.children.length) stopButton.hidden = true;
    }, 5200);
  }

  addButton.addEventListener("click", () => addSticker("🌭", "Sticker hot-dog"));
  pizzaButton.addEventListener("click", () => addSticker("🍕", "Sticker pizza"));
  clearButton.addEventListener("click", removeStickers);
  stopButton.addEventListener("click", stopEverything);
  menuButton.addEventListener("click", () => {
    menu.hidden = !menu.hidden; menuButton.setAttribute("aria-expanded", String(!menu.hidden));
    if (!menu.hidden) gadgetSearch.focus();
  });
  gadgetSearch.addEventListener("input", filterGadgets);
  categoryButtons.forEach(button => button.addEventListener("click", () => {
    activeCategory = button.dataset.category;
    categoryButtons.forEach(item => item.classList.toggle("active", item === button));
    filterGadgets();
  }));
  menu.addEventListener("click", event => {
    const button = event.target.closest("button[data-mode]");
    if (!button) return;
    if (button.dataset.mode === "musicmaker") { menu.hidden = true; menuButton.setAttribute("aria-expanded", "false"); musicWorkshop.hidden = false; }
    else if (button.dataset.mode === "creativelab") creativeLabGadget();
    else if (button.dataset.mode === "pizzamaker") { menu.hidden = true; menuButton.setAttribute("aria-expanded", "false"); pizzaWorkshop.hidden = false; }
    else if (button.dataset.mode === "image") spawnRandomImage();
    else if (button.dataset.mode === "reader") togglePageMode("reader", "hack-reader");
    else if (button.dataset.mode === "contrast") togglePageMode("contrast", "hack-contrast");
    else if (button.dataset.mode === "text") togglePageMode("text", "hack-text");
    else if (button.dataset.mode === "focus") togglePageMode("focus", "hack-focus");
    else if (button.dataset.mode === "copy") copyPageLink();
    else if (button.dataset.mode === "note") takePageNote();
    else if (button.dataset.mode === "top") window.scrollTo({ top: 0, behavior: "smooth" });
    else if (button.dataset.mode === "print") window.print();
    else if (button.dataset.mode === "location") locationGadget();
    else if (button.dataset.mode === "quicksearch") quickSearchGadget();
    else if (button.dataset.mode === "weather") weatherGadget();
    else if (button.dataset.mode === "soundboard") soundboardGadget();
    else if (button.dataset.mode === "calculator") calculatorGadget();
    else if (button.dataset.mode === "checklist") checklistGadget();
    else if (button.dataset.mode === "decision") decisionGadget();
    else if (button.dataset.mode === "readaloud") readSelectionGadget();
    else if (button.dataset.mode === "gradient") gradientGadget();
    else if (button.dataset.mode === "convert") convertGadget();
    else if (button.dataset.mode === "stopwatch") stopwatchGadget();
    else if (button.dataset.mode === "password") passwordGadget();
    else if (button.dataset.mode === "pomodoro") pomodoroGadget();
    else if (button.dataset.mode === "palette") paletteGadget();
    else if (button.dataset.mode === "wordcount") wordCounterGadget();
    else if (button.dataset.mode === "translate") translateGadget();
    else if (button.dataset.mode === "googleTheme") googleThemeGadget();
    else if (button.dataset.mode === "googleWord") googleWordGadget();
    else if (button.dataset.mode === "summary") { const text = [...document.querySelectorAll("main, article, [role='main']")].map(el => el.innerText).join("\n").slice(0, 4000) || document.body.innerText.slice(0, 4000); window.open(`https://www.google.com/search?q=${encodeURIComponent(`résumé ${document.title} ${text.slice(0, 900)}`)}`, "_blank", "noopener"); }
    else if (button.dataset.mode === "define") { const word = window.getSelection()?.toString().trim() || window.prompt("Quel mot définir ?", ""); if (word) window.open(`https://www.google.com/search?q=${encodeURIComponent(`définition ${word}`)}`, "_blank", "noopener"); }
    else if (button.dataset.mode === "starwars") window.open("https://www.disneyplus.com/fr-fr/browse/page-b4e74f38-aa35-4b12-965c-93f4a931f78a", "_blank", "noopener");
    else if (button.dataset.mode === "movie") {
      menu.hidden = true; menuButton.setAttribute("aria-expanded", "false"); movieModal.hidden = false;
      movieModal.querySelector("input").focus();
    }
    else toggleMode(button.dataset.mode);
  });
  toolCard.querySelector(".tool-close").addEventListener("click", () => { toolCard.hidden = true; });
  movieModal.querySelector(".movie-cancel").addEventListener("click", () => { movieModal.hidden = true; });
  movieModal.addEventListener("click", event => { if (event.target === movieModal) movieModal.hidden = true; });
  movieForm.addEventListener("submit", event => {
    event.preventDefault();
    const title = new FormData(movieForm).get("title")?.toString().trim();
    if (!title) return;
    const query = `${title} bande annonce officielle trailer`;
    chrome.runtime.sendMessage({ type: "open-movie-trailer", title: query });
    movieModal.hidden = true;
    movieForm.reset();
  });
})();
