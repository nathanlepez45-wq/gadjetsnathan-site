const messages = [
  "[00:00:01] Initialisation des modules visuels…",
  "[00:00:02] Analyse fictive du réseau local…",
  "[00:00:03] Résolution des nœuds : 12 actifs / 0 cible réelle",
  "[00:00:04] Simulation du chiffrement AES-256… OK",
  "[00:00:05] Ouverture du tunnel de démonstration…",
  "[00:00:06] Chargement des paquets fantômes… terminé",
  "[00:00:07] Vérification des pare-feu imaginaires… OK",
  "[00:00:08] Accès accordé — mode spectacle actif."
];
const codeLines = [
  "const packet = await simulateHandshake(node);",
  "if (sandbox.active) renderTelemetry(frame);",
  "crypto_demo.rotateKey('AES-256');",
  "for (const node of virtualNetwork) {",
  "  node.status = 'SIMULATED';",
  "  await stream.push(makeNoise());",
  "} // demo environment only",
  "socket.connect('127.0.0.1', DEMO_PORT);",
  "checksum = hash(payload + timestamp);",
  "console.log('[VISUAL MODE]');",
  "route = buildFakeRoute(hops);",
  "await dashboard.refresh(metrics);"
];
const log = document.querySelector("#log");
const windowsLayer = document.querySelector("#windows");
let messageIndex = 0;

function addLine() {
  const line = document.createElement("div");
  line.className = "line";
  line.textContent = messages[messageIndex++ % messages.length];
  log.append(line);
  if (log.children.length > 7) log.firstElementChild.remove();
}

function fillCode(selector) {
  const pre = document.querySelector(selector);
  pre.textContent = Array.from({ length: 34 }, (_, i) =>
    `${String(i + 1).padStart(2, "0")}  ${codeLines[Math.floor(Math.random() * codeLines.length)]}`
  ).join("\n");
}
fillCode("#code-left");
fillCode("#code-right");
setInterval(() => { fillCode("#code-left"); fillCode("#code-right"); }, 6500);

const panelTitles = ["SCAN NODE", "PACKET VIEW", "ROUTE MAP", "KEY EXCHANGE", "SYSTEM LOG", "TRACE CONSOLE"];
function spawnWindow() {
  const panel = document.createElement("section");
  panel.className = "ghost-window";
  const title = panelTitles[Math.floor(Math.random() * panelTitles.length)];
  const rows = Array.from({ length: 3 + Math.floor(Math.random() * 3) }, () => {
    const safeLine = codeLines[Math.floor(Math.random() * codeLines.length)].replaceAll("<", "&lt;");
    return `<div>${safeLine}</div>`;
  }).join("");
  panel.innerHTML = `<header><span>◈ ${title}</span><span>— □ ×</span></header><main>${rows}</main>`;
  panel.style.left = `${4 + Math.random() * 75}vw`;
  panel.style.setProperty("--duration", `${4.4 + Math.random() * 2.8}s`);
  panel.style.setProperty("--drift", `${16 + Math.random() * 60}px`);
  windowsLayer.append(panel);
  window.setTimeout(() => panel.remove(), 7800);
}

addLine();
setInterval(addLine, 420);
for (let i = 0; i < 7; i++) setTimeout(spawnWindow, i * 230);
setInterval(spawnWindow, 570);

document.addEventListener("click", () => {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return;
  const context = new AudioContextClass();
  const start = context.currentTime;
  for (let i = 0; i < 44; i++) {
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = i % 3 ? "square" : "sawtooth";
    oscillator.frequency.value = 150 + Math.random() * 1050;
    gain.gain.setValueAtTime(0.0001, start + i * 0.13);
    gain.gain.exponentialRampToValueAtTime(0.035, start + i * 0.13 + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + i * 0.13 + 0.085);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(start + i * 0.13);
    oscillator.stop(start + i * 0.13 + 0.09);
  }
  document.querySelector("#sound-hint").textContent = "SON ACTIVÉ · CLIQUE POUR FERMER";
}, { once: true });

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") window.close();
});
