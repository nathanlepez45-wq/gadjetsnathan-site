const openedForSearch = new Set();

function isHackSearch(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (!/(^|\.)google\.(com|fr)$/.test(url.hostname) || url.pathname !== "/search") return false;
    return url.searchParams.get("q")?.trim().toLowerCase() === "/hack";
  } catch {
    return false;
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.url || !isHackSearch(tab.url)) return;
  if (openedForSearch.has(tabId)) return;
  openedForSearch.add(tabId);
  chrome.windows.create({
    url: chrome.runtime.getURL("hack-show.html"),
    type: "popup",
    state: "fullscreen"
  });
});

chrome.tabs.onRemoved.addListener((tabId) => openedForSearch.delete(tabId));

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "open-movie-trailer" || typeof message.title !== "string") return;
  const title = message.title.trim().slice(0, 120);
  if (!title) return;
  const query = encodeURIComponent(`${title} bande annonce française VF trailer`);
  chrome.windows.create({
    url: `https://www.youtube.com/results?search_query=${query}#hack-trailer-autoplay`,
    type: "popup",
    state: "fullscreen"
  });
});
